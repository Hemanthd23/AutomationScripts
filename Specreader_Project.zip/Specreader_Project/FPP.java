package join;

import org.openqa.selenium.WebDriver;


import java.util.ArrayList;
//import org.testng.annotations.Test;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Assert;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

//import org.testng.asserts.SoftAssert;

public class FPP {
	WebDriver driver;
	public FPP(WebDriver driver) {
		this.driver=driver;
	}
	SoftAssert assertion=new SoftAssert();
	public void beforeClass() throws InterruptedException{

		System.out.println("-------------------------------------------------------------------------------");
		System.out.println("VALIDATION OF FPP OBJECT...");
 		Thread.sleep(5000);
 		driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/div[3]/form/div[1]/input")).sendKeys("FPP");
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/div[3]/form/div[1]/div[2]/button/i")).click();
	      
	      Thread.sleep(2000);
	      System.out.println();
			System.out.println("______________________ FPP OBJECT ___________________________");
			System.out.println();
	      if(driver.findElement(By.linkText("FPP-00012170")).isDisplayed()) {
	    	  driver.findElement(By.linkText("FPP-00012170")).click();
	      }
 		
 		Thread.sleep(1000);

 		
	}
	public void FPP_Attributes() {
		System.out.println("");
		System.out.println("************************Attributes  **************************");
		System.out.println("");

		List<String>attribute=new ArrayList <String>();
		attribute.add("Description");
		attribute.add("Title");
		attribute.add("CO");
		attribute.add("Originator");
		attribute.add("Last Update User");
		attribute.add("Product Form");
		attribute.add("Type");
		attribute.add("Specification Sub Type");
		attribute.add("Revision");
		attribute.add("Originated");
		attribute.add("Phase");
		attribute.add("Owner");
		attribute.add("Segment");
		attribute.add("Structured Release Criteria Required");
		attribute.add("Release Date");
		attribute.add("Effective Date");
		attribute.add("Expiration Date");
		attribute.add("Previous Revision Obsolete Date");
		attribute.add("Manufacturing Status");
		attribute.add("Part Family");
		attribute.add("Reason for Change");
		attribute.add("Replaced Product Name (Phase Out)");
		attribute.add("Brand");
		attribute.add("Base Unit Of Measure");
		attribute.add("Retailer Publication Ready");
		attribute.add("W&D status");
		attribute.add("SAP BOM Base QTY");
		attribute.add("Other Names");
		attribute.add("Local Description");
		attribute.add("Marketing Size");
		attribute.add("Statistical Unit");
		attribute.add("Customization Type");
		attribute.add("Shipping Information");
		attribute.add("Labeling Information");
		attribute.add("Primary Packaging Type");
		attribute.add("Secondary Packaging Type");
		attribute.add("Packaging Size");
		attribute.add("Packaging Size UofM");
		attribute.add("Comments");
		attribute.add("Obsolete Date");
		attribute.add("Obsolete Comment");
		attribute.add("Classification");
		List<WebElement>l=driver.findElements(By.id("pageheaders"));
		for(String s:attribute) {
			int count=0;
			for(WebElement w:l) {
				String s1=w.getText();
				if(s.equalsIgnoreCase(s1)) {
//					Assert.assertEquals(s1, s);
					System.out.println(s+" is present on webpage");
					break;
				
				}
				else {
					count+=1;
					if(count>=l.size()) {
						System.out.println(s+" not in webpage");
//						Assert.assertFalse(true);
					}
					
				continue;
				}
				
			}
		}
		 
		}
	 
	  public void FPP_storage_transport_labelling() throws Exception{
		 
		  System.out.println("");
			System.out.println("************************Storage,Transportation labelling data **************************");
			System.out.println("");

		  WebElement t=driver.findElement(By.id("three"));
			List<WebElement>l=t.findElements(By.id("pageheaders"));
			List<String>attribute=new ArrayList<String>();
			attribute.add("Power Source:");
			attribute.add("Battery Type:");
			attribute.add("UN Number:");
			attribute.add("Hazard Class:");
			attribute.add("Proper Shipping Name:");
			attribute.add("Packing Group:");
			attribute.add("Storage Conditions:");
			attribute.add("Storage Temperature Limits �C:");
			attribute.add("Unique Formula Identifier:");
			attribute.add("Storage Humidity Limits -%:");
			
			for(String s:attribute) {
				int count=0;
				for(WebElement w:l) {
					String s1=w.getText();
					if(s.equalsIgnoreCase(s1)) {
//						Assert.assertEquals(s1, s);
						System.out.println(s+" is present on webpage");
						break;
					
					}
					else {
						count+=1;
						if(count>=l.size()) {
							System.out.println(s+" not in webpage");
//							Assert.assertFalse(true);
						}
						
					continue;
					}
					
				}
			}
	  }
	  
	  public void FPP_warehouse_classification() throws Exception{
		  //warehouse classification
		  System.out.println("");
			System.out.println("************************Warehouse Classification  **************************");
			System.out.println("");

		  Thread.sleep(4000);
		  WebElement t=driver.findElement(By.id("five"));
		  List<WebElement>l=t.findElements(By.id("pageheaders"));
		  List<String>attribute=new ArrayList<String>();
		  attribute.add("Warehousing Classification:");
		  attribute.add("Corrosive:");
		  for(String s:attribute) {
				int count=0;
				for(WebElement w:l) {
					String s1=w.getText();
					if(s.equalsIgnoreCase(s1)) {
//						Assert.assertEquals(s1, s);
						System.out.println(s+" is present on webpage");
						break;
					
					}
					else {
						count+=1;
						if(count>=l.size()) {
							System.out.println(s+" not in webpage");
//							Assert.assertFalse(true);
						}
						
					continue;
					}
					
				}
			}
	  }
	  public void FPP_sapBomfed() {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			System.out.println();
			System.out.println("*************** Sap Bom **************");
			System.out.println();
			List<String> sap=new ArrayList<String>();
			sap.add("Name");
			sap.add("SAP Description");
			sap.add("Type");
			sap.add("Specification SubType");
			sap.add("SAP Type");
			sap.add("Substitute/ Alternate Grouping");
			sap.add("BOM Quantity(BQ)");
			sap.add("Base Unit of Measure(BUoM)");
			sap.add("Authorized(A) Authorized To Use(AU)");
			sap.add("Authorized To Produce(AP) Optional Component (OC)");
			sap.add("Transport Unit(TU) Comments(C)");
			sap.add("BQ");
			sap.add("BUoM");
			sap.add("A");
			sap.add("AU");
			sap.add("AP");
			sap.add("OC");
			sap.add("TU");
			sap.add("C");
			List<String>sap1=new ArrayList<String>();
			WebElement table=driver.findElement(By.xpath("//*[@id=\"six\"]/div/div/table/thead")); 
			List <WebElement> rows=table.findElements(By.tagName("tr"));   
			List <WebElement> cols=rows.get(1).findElements(By.tagName("th"));
			for (WebElement col:cols) {
				String ss=col.getText();
				sap1.add(ss);
			}
			List<String> b=new ArrayList<String>();
			WebElement table2=driver.findElement(By.xpath("//*[@id=\"six\"]/div/div/table/tbody"));
			List <WebElement> rows2=table2.findElements(By.tagName("tr"));
			List <WebElement> cols2=rows2.get(0).findElements(By.className("bomFontClass"));
			for(WebElement col:cols2) {
				String ss=col.getText();
				b.add(ss);
			}
			for(String s:b) {
				for(String ss:s.split(":")) {
					sap1.add(ss);
				}
			}
			for(String s:sap) {
				int count=0;
				for(String s1:sap1) {
					if(s.equalsIgnoreCase(s1)) {
						System.out.println(s+"is present");
						break;
					}
					else {
						count+=1;
						if(count>=sap1.size()) {
							System.out.println(s+" not present");
						}
						continue;
					}
				}
			}
			
		}
	  public void FPP_BoM() throws Exception{
		  //BoM  unit
		  System.out.println("");
			System.out.println("************************ Bill Of Materials  **************************");
			System.out.println("");
			try {
			if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[5]/div[1]/div")).isDisplayed())
			{
//				System.out.println("**************Bill Of Materials****************");
				List<String> bill=new ArrayList<String>();
				bill.add("Name(N) Rev(R)");
				  bill.add("Chg");
				  bill.add("F/N");
				  bill.add("title");
				  bill.add("Type");
				  bill.add("Substitute Parts (SP) Alternate (Alt)");
				  bill.add("Qty");
				  bill.add("Base Unit of Measure");
				  bill.add("EBOM Comments");
				  bill.add("Release Date");
				  bill.add("Phase (Pha) State(St)");
				  bill.add("Ref Des(RD) On-Shelf Product Density(OSPD)");
				  bill.add("Density Unit Of Measure(DUoM) Optional Components(OC)");
				  bill.add("N");
				  bill.add("R");
				  bill.add("Sp");
				  bill.add("Alt");
				  bill.add("Pha");
				  bill.add("St");
				  bill.add("RD");
				  bill.add("OSPD");
				  bill.add("DUoM");
				  bill.add("OC");
				 
				List<String>bill1=new ArrayList<String>();
				WebElement table=driver.findElement(By.xpath("//*[@id=\"eight\"]/div/div/table/thead"));
				List <WebElement> rows=table.findElements(By.tagName("tr"));
				List <WebElement> cols=rows.get(0).findElements(By.tagName("th"));
				for (WebElement col:cols) {
					String ss=col.getText();
					bill1.add(ss);
				}
				List<String> b=new ArrayList<String>();
				WebElement table2=driver.findElement(By.xpath("//*[@id=\"eight\"]/div/div/table/tbody"));
				List <WebElement> rows2=table2.findElements(By.tagName("tr"));
				List <WebElement> cols2=rows2.get(0).findElements(By.className("bomFontClass"));
				for(WebElement col:cols2) {
					String ss=col.getText();
					b.add(ss);
				}
				for(String s:b) {
					for(String ss:s.split(":")) {
						bill1.add(ss);
					}
				}
				for(String s:bill) {
					int count=0;
					for(String s1:bill1) {
						if(s.equalsIgnoreCase(s1)) {
							System.out.println(s+" is present");
							break;
						}
						else {
							count+=1;
							if(count>=bill1.size()) {
								System.out.println(s+" not present");
							}
							continue;
						}
					}
				}
			}
			else {
				System.out.println("bill Of Materials elements is present in template but missing in webpage");
			}
			}
			catch(Exception e) {
				System.out.println("bill Of Materials elements is present in template but missing in webpage");
			}
		  
	  }
	  public void FPP_BoM_Customer() throws Exception{
		  //BoM customer unit
		  System.out.println("");
			System.out.println("***********************Bill Of Materials Customer Unit  **************************");
			System.out.println("");
			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[6]/div[1]/div")).isDisplayed())
				{
		  List<String>bill=new ArrayList<String>();
		  bill.add("Name(N) Rev(R)");
		  bill.add("Chg");
		  bill.add("F/N");
		  bill.add("title");
		  bill.add("Type");
		  bill.add("Substitute Parts (SP) Alternate (Alt)");
		  bill.add("Qty");
		  bill.add("Base Unit of Measure");
		  bill.add("EBOM Comments");
		  bill.add("Release Date");
		  bill.add("Phase (Pha) State(St)");
		  bill.add("Ref Des(RD) On-Shelf Product Density(OSPD)");
		  bill.add("Density Unit Of Measure(DUoM) Optional Components(OC)");

		  bill.add("N");
		  bill.add("R");
		  bill.add("Sp");
		  bill.add("Alt");
		  bill.add("Pha");
		  bill.add("St");
		  bill.add("RD");
		  bill.add("OSPD");
		  bill.add("DUoM");
		  bill.add("OC");
		  List<String>bill1=new ArrayList<String>();
			WebElement table=driver.findElement(By.xpath("//*[@id=\"ten\"]/div/div/table/thead"));
			List <WebElement> rows=table.findElements(By.tagName("tr"));
			List <WebElement> cols=rows.get(0).findElements(By.tagName("th"));
			for (WebElement col:cols) {
				String ss=col.getText();
				bill1.add(ss);
			}
			List<String> b=new ArrayList<String>();
			WebElement table2=driver.findElement(By.xpath("//*[@id=\"ten\"]/div/div/table/tbody"));
			List <WebElement> rows2=table2.findElements(By.tagName("tr"));
			List <WebElement> cols2=rows2.get(0).findElements(By.className("bomFontClass"));
			for(WebElement col:cols2) {
				String ss=col.getText();
				b.add(ss);
			}
			for(String s:b) {
				for(String ss:s.split(":")) {
					bill1.add(ss);
				}
			}
			for(String s:bill) {
				int count=0;
				for(String s1:bill1) {
					if(s.equalsIgnoreCase(s1)) {
						System.out.println(s+" is present");
						break;
					}
					else {
						count+=1;
						if(count>=bill1.size()) {
							System.out.println(s+" not present");
						}
						continue;
					}
				}
			}
		}
		else {
			System.out.println("Bill Of Materials Customer Unit is present in template but missing in webpage");
		}
			}
			catch(Exception e) {
				System.out.println("Bill Of Materials Customer Unit is present in template but missing in webpage");
			}
		  
		  
		  
	  }
	  public void FPP_BoM_Consumer() throws Exception{
		  
		  System.out.println("");
			System.out.println("************************Bill Of Materials Consumer Unit **************************");
			System.out.println("");

			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[7]/div[1]/div")).isDisplayed())
				{
		  List<String>bill=new ArrayList<String>();
		  bill.add("Name(N) Rev(R)");
		  bill.add("Chg");
		  bill.add("F/N");
		  bill.add("title");
		  bill.add("Type");
		  bill.add("Substitute Parts (SP) Alternate (Alt)");
		  bill.add("Qty");
		  bill.add("Base Unit of Measure");
		  bill.add("EBOM Comments");
		  bill.add("Release Date");
		  bill.add("Phase (Pha) State(St)");
		  bill.add("Ref Des(RD) On-Shelf Product Density(OSPD)");
		  bill.add("Density Unit Of Measure(DUoM) Optional Components(OC)");

		  bill.add("N");
		  bill.add("R");
		  bill.add("Sp");
		  bill.add("Alt");
		  bill.add("Pha");
		  bill.add("St");
		  bill.add("RD");
		  bill.add("OSPD");
		  bill.add("DUoM");
		  bill.add("OC");
		  List<String>bill1=new ArrayList<String>();
			WebElement table=driver.findElement(By.xpath("//*[@id=\"fourteen\"]/div/div/table/thead"));
			List <WebElement> rows=table.findElements(By.tagName("tr"));
			List <WebElement> cols=rows.get(0).findElements(By.tagName("th"));
			for (WebElement col:cols) {
				String ss=col.getText();
				bill1.add(ss);
			}
			List<String> b=new ArrayList<String>();
			WebElement table2=driver.findElement(By.xpath("//*[@id=\"fourteen\"]/div/div/table/tbody"));
			List <WebElement> rows2=table2.findElements(By.tagName("tr"));
			List <WebElement> cols2=rows2.get(0).findElements(By.className("bomFontClass"));
			for(WebElement col:cols2) {
				String ss=col.getText();
				b.add(ss);
			}
			for(String s:b) {
				for(String ss:s.split(":")) {
					bill1.add(ss);
				}
			}
			for(String s:bill) {
				int count=0;
				for(String s1:bill1) {
					if(s.equalsIgnoreCase(s1)) {
						System.out.println(s+" is present");
						break;
					}
					else {
						count+=1;
						if(count>=bill1.size()) {
							System.out.println(s+" not present");
						}
						continue;
					}
				}
			}
		}
		else {
			System.out.println("Bill Of Materials Consumer Unit is present in template but missing in webpage");
		}
			}
			catch(Exception e) {
				System.out.println("Bill Of Materials Consumer Unit is present in template but missing in webpage");
			}
		  
		  
	  }
	  public void FPP_substitutes() {
			System.out.println("\n");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				System.out.println("***************substitutes***********************");
				List<String> sub=new ArrayList<String>();
				sub.add("Substitute Parts(SP) REV(R))");
				sub.add("Chg");
				sub.add("Substitution Combination Number(SCN) Title");
				sub.add("Type(T) Specification SubType(SST)");
				sub.add("QTY");
				sub.add("Base Unit of Measure");
				sub.add("Valid Start Date");
				sub.add("Valid Until Date");
				sub.add("Ref Des");
				sub.add("Release Date");
				sub.add("Comments");
				sub.add("Substitute For(SF) Rev(R)");
				sub.add("Type(T) Title(Ti)");
				sub.add("Specification Sub Type(SST) Optional Components(OC)");
				sub.add("SP");
				sub.add("R");
				sub.add("SCN");
				sub.add("Title");
				sub.add("T");
				sub.add("SST");
				sub.add("SF");
				sub.add("R");
				sub.add("T");
				sub.add("Ti");
				sub.add("OC");
				sub.add("SST");

				List<String>sub11=new ArrayList<String>();
				WebElement table=driver.findElement(By.xpath("//*[@id=\"fifteen\"]/div/div/table/thead"));
				List <WebElement> rows=table.findElements(By.tagName("tr"));
				List <WebElement> cols=rows.get(0).findElements(By.tagName("th"));
				for (WebElement col:cols) {
					String ss=col.getText();
					sub11.add(ss);
				}
				List<String> b=new ArrayList<String>();
				WebElement table2=driver.findElement(By.xpath("//*[@id=\"fifteen\"]/div/div/table/tbody"));
				List <WebElement> rows2=table2.findElements(By.tagName("tr"));
				List <WebElement> cols2=rows2.get(0).findElements(By.className("bomFontClass"));
				for(WebElement col:cols2) {
					String ss=col.getText();
					b.add(ss);
				}
				for(String s:b) {
					for(String ss:s.split(":")) {
						sub11.add(ss);
					}
				}
				for(String s:sub) {
					int count=0;
					for(String s1:sub11) {
						if(s.equalsIgnoreCase(s1)) {
							System.out.println(s+" is present");
							break;
						}
						else {
							count+=1;
							if(count>=sub11.size()) {
								System.out.println(s+" not present");
							}
							continue;
						}
					}
				}
		}
	  public void FPP_BoM_Transport() throws Exception{
		  //BoM Transport unit
		  System.out.println("");
			System.out.println("************************Bill Of Materials Transport  Unit **************************");
			System.out.println("");

			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[9]/div[1]/div")).isDisplayed())
				{
		  List<String>bill=new ArrayList<String>();
		  bill.add("Name(N) Rev(R)");
		  bill.add("Chg");
		  bill.add("F/N");
		  bill.add("title");
		  bill.add("Type");
		  bill.add("Substitute Parts (SP) Alternate (Alt)");
		  bill.add("Qty");
		  bill.add("Base Unit of Measure");
		  bill.add("EBOM Comments");
		  bill.add("Release Date");
		  bill.add("Phase (Pha) State(St)");
		  bill.add("Ref Des(RD) On-Shelf Product Density(OSPD)");
		  bill.add("Density Unit Of Measure(DUoM) Optional Components(OC)");

		  bill.add("N");
		  bill.add("R");
		  bill.add("Sp");
		  bill.add("Alt");
		  bill.add("Pha");
		  bill.add("St");
		  bill.add("RD");
		  bill.add("OSPD");
		  bill.add("DUoM");
		  bill.add("OC");
		  List<String>bill1=new ArrayList<String>();
			WebElement table=driver.findElement(By.xpath("//*[@id=\"sixteen\"]/div/div/table/thead"));
			List <WebElement> rows=table.findElements(By.tagName("tr"));
			List <WebElement> cols=rows.get(0).findElements(By.tagName("th"));
			for (WebElement col:cols) {
				String ss=col.getText();
				bill1.add(ss);
			}
			List<String> b=new ArrayList<String>();
			WebElement table2=driver.findElement(By.xpath("//*[@id=\"sixteen\"]/div/div/table/tbody"));
			List <WebElement> rows2=table2.findElements(By.tagName("tr"));
			List <WebElement> cols2=rows2.get(0).findElements(By.className("bomFontClass"));
			for(WebElement col:cols2) {
				String ss=col.getText();
				b.add(ss);
			}
			for(String s:b) {
				for(String ss:s.split(":")) {
					bill1.add(ss);
				}
			}
			for(String s:bill) {
				int count=0;
				for(String s1:bill1) {
					if(s.equalsIgnoreCase(s1)) {
						System.out.println(s+" is present");
						break;
					}
					else {
						count+=1;
						if(count>=bill1.size()) {
							System.out.println(s+" not present");
						}
						continue;
					}
				}
			}
		}
		else {
			System.out.println("Bill Of Materials Transport Unit is present in template but missing in webpage");
		}
			}
			catch(Exception e) {
				System.out.println("Bill Of Materials Transport Unit is present in template but missing in webpage");
			}
		  
		  
	  }
	  
	  
	  public void FPP_BoM_Master_Customer() throws Exception{
		  //BoM Master customer unit
		  System.out.println("");
			System.out.println("************************Bill Of Materials Master Customer Unit  **************************");
			System.out.println("");

			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[10]/div[1]/div")).isDisplayed())
				{
		  List<String>bill=new ArrayList<String>();
		  bill.add("Name(N) Rev(R)");
		  bill.add("Chg");
		  bill.add("F/N");
		  bill.add("title");
		  bill.add("Type");
		  bill.add("Substitute Parts (SP) Alternate (Alt)");
		  bill.add("Qty");
		  bill.add("Base Unit of Measure");
		  bill.add("EBOM Comments");
		  bill.add("Release Date");
		  bill.add("Phase (Pha) State(St)");
		  bill.add("Ref Des(RD) On-Shelf Product Density(OSPD)");
		  bill.add("Density Unit Of Measure(DUoM) Optional Components(OC)");

		  bill.add("N");
		  bill.add("R");
		  bill.add("Sp");
		  bill.add("Alt");
		  bill.add("Pha");
		  bill.add("St");
		  bill.add("RD");
		  bill.add("OSPD");
		  bill.add("DUoM");
		  bill.add("OC");
		  List<String>bill1=new ArrayList<String>();
			WebElement table=driver.findElement(By.xpath("//*[@id=\"eighteen\"]/div/div/table/thead"));
			List <WebElement> rows=table.findElements(By.tagName("tr"));
			List <WebElement> cols=rows.get(0).findElements(By.tagName("th"));
			for (WebElement col:cols) {
				String ss=col.getText();
				bill1.add(ss);
			}
			List<String> b=new ArrayList<String>();
			WebElement table2=driver.findElement(By.xpath("//*[@id=\"eighteen\"]/div/div/table/tbody"));
			List <WebElement> rows2=table2.findElements(By.tagName("tr"));
			List <WebElement> cols2=rows2.get(0).findElements(By.className("bomFontClass"));
			for(WebElement col:cols2) {
				String ss=col.getText();
				b.add(ss);
			}
			for(String s:b) {
				for(String ss:s.split(":")) {
					bill1.add(ss);
				}
			}
			for(String s:bill) {
				int count=0;
				for(String s1:bill1) {
					if(s.equalsIgnoreCase(s1)) {
						System.out.println(s+" is present");
						break;
					}
					else {
						count+=1;
						if(count>=bill1.size()) {
							System.out.println(s+" not present");
						}
						continue;
					}
				}
			}
		}
		else {
			System.out.println("Bill Of Materials Master Customer Unit is present in template but missing in webpage");
		}
			}
			catch(Exception e) {
				System.out.println("Bill Of Materials Master Customer Unit is present in template but missing in webpage");
			}
		  
		  
	  }
	  public void FPP_BoM_Master_Consumer() throws Exception{
		  //BoM Master consumer unit
		  System.out.println("");
			System.out.println("************************Bill Of Materials Master Consumer Unit  **************************");
			System.out.println("");

			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[11]/div[1]/div")).isDisplayed())
				{
		  List<String>bill=new ArrayList<String>();
		  bill.add("Name(N) Rev(R)");
		  bill.add("Chg");
		  bill.add("F/N");
		  bill.add("title");
		  bill.add("Type");
		  bill.add("Substitute Parts (SP) Alternate (Alt)");
		  bill.add("Qty");
		  bill.add("Base Unit of Measure");
		  bill.add("EBOM Comments");
		  bill.add("Release Date");
		  bill.add("Phase (Pha) State(St)");
		  bill.add("Ref Des(RD) On-Shelf Product Density(OSPD)");
		  bill.add("Density Unit Of Measure(DUoM) Optional Components(OC)");

		  bill.add("N");
		  bill.add("R");
		  bill.add("Sp");
		  bill.add("Alt");
		  bill.add("Pha");
		  bill.add("St");
		  bill.add("RD");
		  bill.add("OSPD");
		  bill.add("DUoM");
		  bill.add("OC");
		  List<String>bill1=new ArrayList<String>();
			WebElement table=driver.findElement(By.xpath("//*[@id=\"twentytwo\"]/div/div/table/thead"));
			List <WebElement> rows=table.findElements(By.tagName("tr"));
			List <WebElement> cols=rows.get(0).findElements(By.tagName("th"));
			for (WebElement col:cols) {
				String ss=col.getText();
				bill1.add(ss);
			}
			List<String> b=new ArrayList<String>();
			WebElement table2=driver.findElement(By.xpath("//*[@id=\"twentytwo\"]/div/div/table/tbody"));
			List <WebElement> rows2=table2.findElements(By.tagName("tr"));
			List <WebElement> cols2=rows2.get(0).findElements(By.className("bomFontClass"));
			for(WebElement col:cols2) {
				String ss=col.getText();
				b.add(ss);
			}
			for(String s:b) {
				for(String ss:s.split(":")) {
					bill1.add(ss);
				}
			}
			for(String s:bill) {
				int count=0;
				for(String s1:bill1) {
					if(s.equalsIgnoreCase(s1)) {
						System.out.println(s+" is present");
						break;
					}
					else {
						count+=1;
						if(count>=bill1.size()) {
							System.out.println(s+" not present");
						}
						continue;
					}
				}
			}
		}
		else {
			System.out.println("Bill Of Materials Master Consumer Unit is present in template but missing in webpage");
		}
			}
			catch(Exception e) {
				System.out.println("Bill Of Materials Master Consumer Unit is present in template but missing in webpage");
			}
		  
		  
	  }
	  public void FPP_Master_Specifications() {
		  List<String>master=new ArrayList<String>();
		  master.add("Name");
		  master.add("Title");
		  master.add("Type");
		  master.add("Master Part Name");
		  master.add("Specification SubType");
		  System.out.println("");
			System.out.println("************************Master_Specification  **************************");
			System.out.println("");
		  WebElement t= driver.findElement(By.id("twentyfive"));
		  List<WebElement> ma=t.findElements(By.tagName("th"));
		  for(String s:master) {
			  int count=0;
			  for(WebElement w:ma) {
				  String s1=w.getText();
				  if(s.equalsIgnoreCase(s1)) {
//					  Assert.assertEquals(s1,s);
					  System.out.println(s+ "  is present on webpage");
					  break;
				  }
				  else {
					  count+=1;
					  if(count>=ma.size()) {
						  System.out.println(s+"is not there on webpage");
					  }
					  continue;
				  }
			  }}
		  }
	  public void FPP_performanceCharacteristic() {
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			System.out.println("Validation of Performance characteristic web table is in progress...");
			System.out.println("");
			System.out.println("************************Performance Characteristics  **************************");
			System.out.println("");

			List<String> per=new ArrayList<String>();
			
			per.add("Chg");
			per.add("Characteristic(Ch) Characteristic Specifics(CS) Path(P)");
			per.add("Test Method (Name) Test Method Logic(TML) Te st Method Origin (TMO) Other Test Method Number (TM#) Test Method	Specifics (Sp) Test Method	Reference Document	Name(TMRDN)");
			per.add("Sampling(SM) Subgroup(SG)");
			per.add("Plant Testing Level(LVL) Plant Testing:Retesting(RT) Retesting Unit Of Measure(UoM)");
			per.add("Lower Specification Limit (LSL) Lower Routine Release Limit(LRRL) Lower Target(LTGT) Target(TGT) Upper Target(UTGT) Upper Routine Release Limit(URRL) Upper Specification Limit (USL)");
			per.add("Unit of Measure(UoM) Report to Nearest(RTN) Report Type(RT)");
			per.add("Release Criteria(RC)");
			per.add("Action Required(AC) Criticality Factor(CR) Basis(BA)");
			per.add("Test Group(TG) Application(AP) Master Part Title(MPT)");
			per.add("CH");
			per.add("CS");
			per.add("P");
			per.add("Name");
			per.add("TML");
			per.add("TMO");
			per.add("TM#");
			per.add("SP");
			per.add("TMRDN");
			per.add("SM");
			per.add("SG");
			per.add("LVL");
			per.add("RT");
			per.add("UoM");
			per.add("LSL");
			per.add("LRRL");
			per.add("");
			per.add("");
			per.add("LTGT");
			per.add("TGT");
			per.add("UTGT");
			per.add("URRL");
			per.add("USL");
			per.add("UOM");
			per.add("RTN");
			per.add("RT");
			per.add("RC");
			per.add("AC");
			per.add("CR");
			per.add("BA");
			per.add("TG");
			per.add("AP");
			per.add("MPT");
			List<String>per1=new ArrayList<String>();
			WebElement table=driver.findElement(By.id("twentyseven"));
			List <WebElement> rows=table.findElements(By.tagName("tr"));
			List <WebElement> cols=rows.get(0).findElements(By.tagName("th"));
			for (WebElement col:cols) {
				String ss=col.getText();
				per1.add(ss);
			}
			List<String> b=new ArrayList<String>();
			WebElement table2=driver.findElement(By.xpath("//*[@id=\"twentyseven\"]/div/div/table/tbody"));
			List <WebElement> rows2=table2.findElements(By.tagName("tr"));
			List <WebElement> cols2=rows2.get(0).findElements(By.className("bomFontClass"));
			for(WebElement col:cols2) {
				String ss=col.getText();
				b.add(ss);
			}
			for(String s:b) {
				for(String ss:s.split(":")) {
					per1.add(ss);
				}
			}
			for(String s:per) {
				int count=0;
				for(String s1:per1) {
					if(s.equalsIgnoreCase(s1)) {
						System.out.println(s+"is present");
						break;
					}
					else {
						count+=1;
						if(count>=per1.size()) {
							System.out.println(s+" not present in webtable");
						}
						continue;
					}
				}
			}
			
		}
		  public void FPP_Market_Of_Sales() throws Exception{
			  System.out.println("");
				System.out.println("************************Market Of Sales  **************************");
				System.out.println("");

			  List<String> val=new ArrayList<String>();
				val.add("Market of Sale");
				val.add("Market of Sale Restrictions");
				WebElement t=driver.findElement(By.id("twentyeight"));
				List<WebElement>h1=t.findElements(By.tagName("th"));
				for(String s1:val) {
					int c=0;
				for(WebElement w:h1) {
					String s=w.getText();
					if(s1.equalsIgnoreCase(s)) {
//						Assert.assertEquals(s1, s);
						System.out.println(s1+" is present on webpage");
					}
					else {
						c+=1;
						if(c>=h1.size()) {
						System.out.println(s1+" not in webpage");
//						Assert.assertFalse(true);
						}
						continue;
					}
				}}
			  }
		  
		  
	  

	  public void FPP_Plants() {
		 

		  List<String>plants=new ArrayList<String>();
		  plants.add("Plants");
		  plants.add("Plants Authorized To Use");
		  plants.add("Plants Authorized to Produce");
		 
		  System.out.println("");
			System.out.println("************************Plants  **************************");
			System.out.println("");
		  WebElement t= driver.findElement(By.id("twentynine"));
		  List<WebElement> pl=t.findElements(By.tagName("th"));
		  for(String s:plants) {
			  int count=0;
			  for(WebElement w:pl) {
				  String s1=w.getText();
				  if(s.equalsIgnoreCase(s1)) {
//					  Assert.assertEquals(s1,s);
					  System.out.println(s+ "  is present on webpage");
					  break;
				  }
				  else {
					  count+=1;
					  if(count>=pl.size()) {
						  System.out.println(s+"is not there on webpage");
					  }
					  continue;
				  }
			  }
		  } 
	  }
	  public void FPP_lifecycle() throws InterruptedException {
			
			Thread.sleep(5000);
			List<String>life=new ArrayList<String>();
			life.add("Tasks/Signatures");
			life.add("Name");
			life.add("Approver");
			life.add("Title");
			life.add("Approval Status");
			life.add("Approval/Due Date");
			life.add("Comments/Instructions");
			 System.out.println("");
				System.out.println("************************Lifecycle  **************************");
				System.out.println("");
			List<String>val=new ArrayList<String>();
			
		WebElement ltable=driver.findElement(By.id("thirty"));
			List<WebElement>rows=ltable.findElements(By.tagName("th"));
			
				for(WebElement c:rows) {
					String sc=c.getText();
					val.add(sc);
					System.out.println(sc);
				}
			
			for(String s:life) {
				int count=0;
				for(String w:val) {
					if(s.equalsIgnoreCase(w)) {
//						Assert.assertEquals(s,w);
						System.out.println(s+" is present on webpage");
						break;
					}


					else {
						count+=1;
						if(count>=val.size()) {
							System.out.println(s+" not in webpage");
						}

						continue;
					}
				}
			}
			
		}	
	  public void FPP_Ownership() throws Exception {
		  Thread.sleep(2000);
			try {
				if (driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[17]/div[1]/div"))
						.isDisplayed()) {
					List<String> Owner = new ArrayList<String>();
					Owner.add("Originator");
					Owner.add("Segment");
					Owner.add("Approvers");
					Owner.add("Last Update User");
					Owner.add("Last Update Date");

					System.out.println("");
					System.out.println("************************* Ownership **************************");
					System.out.println("");
					Thread.sleep(2000);
					List<String> L1 = new ArrayList<String>();
					List<String> L2 = new ArrayList<String>();
					WebElement ownership = driver.findElement(By.xpath("//*[@id=\"thirtyone\"]"));
					List<WebElement> L3 = ownership.findElements(By.id("pageheaders"));
					for (WebElement col : L3) {
						String s1 = col.getText();
						L1.add(s1);
					}
					for (String s2 : L1) {
						for (String s1 : s2.split(":")) {
							L2.add(s1);
						}
					}
					for (String s : Owner) {
						int count = 0;
						for (String s1 : L2) {
							if (s.equalsIgnoreCase(s1)) {
								System.out.println(s + " is present on webpage");
								break;

							}

							else {
								count += 1;
								if (count >= L2.size()) {
									System.out.println(s + " present in template but missing in webpage");
								}

								continue;
							}

						}
					}
				}
			} catch (Exception e) {
				System.out.println("Ownership present in template but missing in webpage");
				System.out.println();
			}
		}
			
			public void FPP_IPClasses() {
				List<String>IPclasses=new ArrayList<String>();
				IPclasses.add("Name");
				IPclasses.add("Has Class Access?");
				IPclasses.add("Type");
				IPclasses.add("Description");
				IPclasses.add("State");
				 System.out.println("");
					System.out.println("************************IPClasses  **************************");
					System.out.println("");
				List<String>IPclass=new ArrayList<String>();
				WebElement table=driver.findElement(By.id("thirtytwo"));
				List<WebElement> cols=table.findElements(By.tagName("th"));
				for(WebElement c:cols) {
					String ss2=c.getText();
					IPclass.add(ss2);
					System.out.println(ss2);
				}
				for(String s:IPclasses) {
					int count=0;
					for(String w:IPclass) {
						
						if(s.equalsIgnoreCase(w)) {
							System.out.println(s+" is present on webpage");	
							break;
						}
						else {
							count+=1;
							if(count>=IPclass.size()) {
								System.out.println(s+" not in webpage");
							}
							continue;
						}
					}
				}
			}
			public void FPP_Weights_Dimensions() {
				List<String>weight=new ArrayList<String>();
				weight.add("W&D Status:");
				weight.add("Unit Of Measure System:");
				
				 System.out.println("");
					System.out.println("************************Weights&Dimension  **************************");
					System.out.println("");
				List<String>wt=new ArrayList<String>();
				WebElement table=driver.findElement(By.id("thirtyfour"));
				List<WebElement> cols=table.findElements(By.id("pageheaders"));
				for(WebElement c:cols) {
					String ss2=c.getText();
					wt.add(ss2);
					System.out.println(ss2);
				}
				for(String s:weight) {
					int count=0;
					for(String w:wt) {
						
						if(s.equalsIgnoreCase(w)) {
							System.out.println(s+" is present on webpage");	
							break;
						}
						else {
							count+=1;
							if(count>=wt.size()) {
								System.out.println(s+" not in webpage");
							}
							continue;
						}
					}
				}
			}
			 public void FPP_packaging_unit() throws Exception{
				  //Packaging unit
				 System.out.println("");
					System.out.println("************************Packaging Unit  **************************");
					System.out.println("");

				  Thread.sleep(4000);
				  WebElement table=driver.findElement(By.id("thirtyfive"));
				  List<WebElement>rows=table.findElements(By.tagName("tr"));
				  List<String>actual_head=new ArrayList<String>();
				  for(int i=0;i<rows.size();i++) {
					  List<WebElement>head=rows.get(i).findElements(By.tagName("th"));
					  for(WebElement h:head) {
						  String s=h.getText();
						  actual_head.add(s);
					  }
				  }
				  
				  List<String>header=new ArrayList<String>();
				  header.add("Packaging Unit Type");
				  header.add("AUOM");
				  header.add("GTIN");
				  header.add("Dimensions - OD with Bulge");
				  header.add("Depth");
				  header.add("Width");
				  header.add("Height");
				  header.add("Dimension Unit of Measure");
				  header.add("Gross Weight");
				  header.add("Unit of Measure");
				  header.add("Number of Consumer Units per Unit");
				  header.add("Net Weight of Product in Consumer Unit");
				  header.add("Unit of Measure");
				  for(String s:header) {
					  int count=0;
					  for(String s1:actual_head) {
						  
						  if(s.equalsIgnoreCase(s1)) {
							  System.out.println(s+" present on the webtable as header");
//							  Assert.assertEquals(s1, s);
							  break;
						  }
						  else {
							  count+=1;
							  if(count>=actual_head.size()) {
								  System.out.println(s+" not present on the webtable as header");
//								  Assert.assertFalse(true);
							  }
							  continue;
						  }
					  }
				  }
				  
				  
			  }
			 public void FPP_transport_unit() throws Exception{
				  //transport unit
				 System.out.println("");
					System.out.println("************************Transport Unit  **************************");
					System.out.println("");

				  WebElement trans=driver.findElement(By.id("thirtysix"));
				  List<WebElement>rows=trans.findElements(By.tagName("tr"));
				  List<String>actual_head=new ArrayList<String>();
				  List<String>header=new ArrayList<String>();
				  header.add("Pallet Type");
				  header.add("GTIN");
				  header.add("Dimensions - OD with Bulge");
				  header.add("Depth");
				  header.add("Width");
				  header.add("Height");
				  header.add("Dimension Unit of Measure");
				  header.add("Gross Weight with Pallet");
				  header.add("Gross Weight Without Pallet");
				  header.add("Unit of Measure");
				  header.add("Number of Customer Units Per Layer");
				  header.add("Number of Layers per Transport Unit");
				  header.add("Number of Customer Units Per Transport Unit");
				  header.add("Warehouse:Pallet Stack Height Maximum");
				  header.add("Warehouse:Case Stack Height Maximum");
				  header.add("Truck:Pallet Stack Height Maximum");
				  header.add("Stacking Pattern GCAS Code");
				  header.add("Cube Efficiency");
				  header.add("Include in SAP BOM Field");
				  
				  for(int i=0;i<=3;i++) {
					  if(i!=2) {
						  List<WebElement>head=rows.get(i).findElements(By.tagName("th"));
						  for(WebElement h:head) {
							  String s=h.getText();
							  actual_head.add(s);
						  }
						  
					  }
				  }
				  for(String s:header) {
					  int count=0;
					  for(String s1:actual_head) {
						  
						  if(s.equalsIgnoreCase(s1)) {
							  System.out.println(s+" present on the webtable as header");
//							  Assert.assertEquals(s1, s);
							  break;
						  }
						  else {
							  count+=1;
							  if(count>=actual_head.size()) {
								  System.out.println(s+" not present on the webtable ");
//								  Assert.assertFalse(true);
							  }
							  continue;
						  }
					  }
				  }
				  
				  
				  
			  }
			 public void FPP_Organizations() {
					List<String>organizations=new ArrayList<String>();
					organizations.add("Primary Organization");
					organizations.add("Secondary Organization");
					  System.out.println("");
						System.out.println("************************Organizations  **************************");
						System.out.println("");
					List<String>organ=new ArrayList<String>();
					WebElement table=driver.findElement(By.id("thirtyeight"));
					List<WebElement>cols=table.findElements(By.id("pageheaders"));
					for(WebElement r:cols) {
						String ss=r.getText();
						organ.add(ss);
						System.out.println(ss);
					}
					for(String s:organizations) {
						int count=0;
						for(String w:organ) {
							
							
						if(s.equalsIgnoreCase(w)) {
								System.out.println(s+" is present on webpage");	
								break;
						}
							else {
								count+=1;
								if(count>=organ.size()) {
									System.out.println(s+" not in webpage");
								}
								continue;
					}
					
			  }
			  }
					
				}
			 public void FPP_Goods_Classification() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Dangerous Goods Classification **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Dangerous Goods Classification")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Dangerous Goods Classification webelement not found in webpage");
						System.out.println();
						
					}
				}
				
				public void FPP_Global() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Global Harmonized Standard  **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Global Harmonized Standard")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Global Harmonized Standard webelement not found in webpage");
						System.out.println();
						
					}
				}
				public void FPP_Notes() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Notes **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Notes")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Notes webelement not found in webpage");
						System.out.println();
						
					}
				}
				
				public void FPP_Stability() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Stability Document **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Stability Document ")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Stability Document  webelement not found in webpage");
						System.out.println();
						
					}
				}
				public void FPP_BOM_innerpack() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Bill Of Materials Inner Pack **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Bill Of Materials Inner Pack ")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Bill Of Materials Inner Pack webelement not found in webpage");
						System.out.println();
						
					}
				}
				public void FPP_Substitutesinner() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Substitutes Inner Pack**************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Substitutes Inner Pack ")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Substitutes Inner Pack  webelement not found in webpage");
						System.out.println();
						
					}
				}
				public void FPP_SubstitutesTransport() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Substitutes Transport Unit **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Substitutes Transport Unit ")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Substitutes Transport Unit  webelement not found in webpage");
						System.out.println();
						
					}
				}
				public void FPP_Substitutesmasterconsumer() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Substitutes Master Consumer Unit **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Substitutes Master Consumer Unit ")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Substitutes Master Consumer Unit  webelement not found in webpage");
						System.out.println();
						
					}
				}
				public void FPP_Related_Specifications() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Related_Specifications **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Related_Specifications ")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Related_Specifications  webelement not found in webpage");
						System.out.println();
						
					}
				}
				public void FPP_Reference_Documents() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Reference Documents **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Reference Documents ")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Reference Documents webelement not found in webpage");
						System.out.println();
						
					}
				}
				public void FPP_Related_ATS() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Related ATS **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Related ATS ")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Related ATS webelement not found in webpage");
						System.out.println();
						
					}
				}
				public void FPP_Certifications() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("************************Certifications **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Certifications ")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Certifications webelement not found in webpage");
						System.out.println();
						
					}
				}
				public void FPP_Files() {
					System.out.println("\n");
//					driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
					 System.out.println("");
						System.out.println("***********************Files **************************");
						System.out.println("");
					try {
						if(driver.findElement(By.linkText("Files ")).isDisplayed()) {}
					}
					catch(Exception e) {
						System.out.println("Files webelement not found in webpage");
						System.out.println();
						
					}
				}



				
			 public void afterClass() {
				  System.out.println("");
					System.out.println("________________________ FPP successfully completed ___________________________");
					System.out.println("");
			  }
	}
	
