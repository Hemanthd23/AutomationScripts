package join;

import java.io.FileReader;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SpecReader_Automation_Tester {
	public static void main(String[] args) throws Exception {
		System.out.println("--------------------------------------------------------------------");
		System.out.println("           Welcome To SpecReader WebPage Testing        ");
		System.out.println("--------------------------------------------------------------------");
		SpecReader_Automation_Tester test = new SpecReader_Automation_Tester();
		test.test();
	}

	@Test
	public void test() throws Exception {
		FileReader reader=new FileReader("C:\\Users\\cad\\eclipse-workspace\\AccProject\\src\\main\\java\\join\\DataFile.properties");  
	      
	    Properties p=new Properties();  
	    p.load(reader);
	    String driverpath=p.getProperty("ChromeDriverPath");
	    String username=p.getProperty("UserName");
	    String password=p.getProperty("Password");
	    String url=p.getProperty("URL");
//	    System.out.println(driverpath+"\n"+username+"\n"+password+"\n"+url);
	    
		System.out.println("Web Page Login");
		System.setProperty("webdriver.chrome.driver", driverpath);
		WebDriver driver = new ChromeDriver();
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.id("username")).sendKeys(username);
		driver.manage().timeouts().implicitlyWait(2000, TimeUnit.SECONDS);
		driver.findElement(By.id("password")).sendKeys(password);
		driver.manage().timeouts().implicitlyWait(50000, TimeUnit.SECONDS);
		driver.findElement(By.id("loginButton")).click();
		driver.manage().timeouts().implicitlyWait(50000, TimeUnit.SECONDS);
		
		Objects obj = new Objects(driver);
		obj.ARMP();
		obj.APMP();
		obj.APP();
		obj.COP();
		obj.CUP();
		obj.DPP();
		obj.FAB();
		obj.FOP();
		obj.FPP();
		obj.IP();
		obj.IRMS();
		obj.MCOP();
		obj.MCUP();
		obj.MEP();
		obj.MIP();
		obj.MPAP();
		obj.MPMP();
		obj.MPP();
		obj.MRMP();
		obj.OPP();
		obj.PAP();
		obj.PIP();
		obj.PMP();
		obj.RMP();
		obj.SEP();
		obj.TUP();
		
		
		
		System.out.println("--------------------------------------------------------------------");
		System.out.println("              SpecReader WebPage Tested Successfully        ");
		System.out.println("--------------------------------------------------------------------");
		driver.quit();
	}

}
