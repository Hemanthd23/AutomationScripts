package join;

//import org.testng.annotations.Test;

import org.openqa.selenium.WebDriver;

//import org.testng.annotations.Test;
import java.util.ArrayList;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.annotations.AfterMethod;
//import org.testng.annotations.BeforeClass;
import org.testng.Assert;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class MPMP {
	WebDriver driver;

	public MPMP(WebDriver driver) {
		this.driver = driver;
	}

	SoftAssert assertion = new SoftAssert();

	public void beforeClass() throws InterruptedException {

		System.out.println("-------------------------------------------------------------------------------");
		System.out.println("VALIDATION OF MPMP OBJECT...");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/div[3]/form/div[1]/input")).sendKeys("MPMP");
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/div[3]/form/div[1]/div[2]/button/i")).click();

		Thread.sleep(2000);
		System.out.println();
		System.out.println("______________________ MPMP OBJECT ___________________________");
		System.out.println();
		if (driver.findElement(By.linkText("MPMP-00000706")).isDisplayed()) {
			driver.findElement(By.linkText("MPMP-00000706")).click();
		}

		Thread.sleep(1000);

	}

	public void MPMP_Attributesvalidate() throws InterruptedException {

		List<String> Attributes = new ArrayList<String>();
		Attributes.add("Title");
		Attributes.add("Originator");
		Attributes.add("Originated");
		Attributes.add("Owner");
		Attributes.add("Segment");
		Attributes.add("Owner");
		Attributes.add("Effective Date");
		Attributes.add("Manufacturing Status");
		Attributes.add("Class");
		Attributes.add("Local Description");
		Attributes.add("Outer Dimension Depth");
		Attributes.add("Project Initiative MileStone");
		Attributes.add("POA Impact Confirmation?");
		Attributes.add("Packaging Component Type");
		Attributes.add("Packaging Technology");
		Attributes.add("Shipping Information");
		Attributes.add("Storage Temperature Limits �C");
		Attributes.add("Obsolete Date");
		Attributes.add("Description");
		Attributes.add("Last Update User");
		Attributes.add("Phase");
		Attributes.add("Segment");
		Attributes.add("Expiration Date");
		Attributes.add("Reason for Change");
		Attributes.add("Sub Class");
		Attributes.add("Other Names");
		Attributes.add("Outer Dimension Height");
		Attributes.add("Inner Dimension Depth");
		Attributes.add("Dimension Unit Of Measure");
		Attributes.add("Packaging Size");
		Attributes.add("Printing Process");
		Attributes.add("Labelling Information");
		Attributes.add("Storage Humidity Limits - %");
		Attributes.add("Obsolete Comment");
		Attributes.add("Type");
		Attributes.add("Revision");
		Attributes.add("Structured Release Criteria Required");
		Attributes.add("Release Date");
		Attributes.add("Previous Revision Obsolete Date");
		Attributes.add("Brand");
		Attributes.add("Reported Function");
		Attributes.add("Outer Dimension Width");
		Attributes.add("Inner Dimension Width");
		Attributes.add("Inner Dimension Height");
		Attributes.add("Packaging Material Type");
		Attributes.add("Packaging Size UoM");
		Attributes.add("Decoration Details");
		Attributes.add("Storage Conditions");
		Attributes.add("Comments");
		Attributes.add("Classification");
		System.out.println("");
		System.out.println("************************Attributes **************************");
		System.out.println("");
		WebElement t = driver.findElement(By.id("collapseZero"));
		List<WebElement> l = t.findElements(By.id("pageheaders"));
		for (String s : Attributes) {
			int count = 0;
			for (WebElement w : l) {
				String s1 = w.getText();
				if (s.equalsIgnoreCase(s1)) {
					Assert.assertEquals(s1, s);
					System.out.println(s + " is present on webpage");
					break;
				} else {
					count += 1;
					if (count >= l.size()) {
						System.out.println(s + " not there on webpage");
					}
					continue;
				}
			}
		}

	}

	public void MPMP_Ownership() throws InterruptedException {

		List<String> Attributes = new ArrayList<String>();
		Attributes.add("Originator:");
		Attributes.add("Co-Owners:");
		Attributes.add("Last Update User:");
		Attributes.add("Segment");
		Attributes.add("Approvers:");
		Attributes.add("Last Update Date:");
		System.out.println("");
		System.out.println("************************Ownership **************************");
		System.out.println("");
		WebElement t = driver.findElement(By.id("collapseSeven"));
		List<WebElement> l = t.findElements(By.id("pageheaders"));
		for (String s : Attributes) {
			int count = 0;
			for (WebElement w : l) {
				String s1 = w.getText();
				if (s.equalsIgnoreCase(s1)) {
					Assert.assertEquals(s1, s);
					System.out.println(s + " is present on webpage");
					break;
				} else {
					count += 1;
					if (count >= l.size()) {
						System.out.println(s + " not there on webpage");
					}
					continue;
				}
			}
		}
	}

	public void MPMP_IP_Classes() throws InterruptedException {
		List<String> Attributes = new ArrayList<String>();
		Attributes.add("Name");
		Attributes.add("Has Class Access?");
		Attributes.add("Type");
		Attributes.add("Description");
		Attributes.add("State");
		System.out.println("");
		System.out.println("************************IP Classes **************************");
		System.out.println("");
		List<String> val = new ArrayList<String>();
		WebElement table = driver.findElement(By.id("collapseTwentyFive"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));

		int rsize = rows.size();
		for (int i = 0; i < rsize; i++) {
			List<WebElement> cols = rows.get(1).findElements(By.tagName("th"));
			for (WebElement c : cols) {
				String sc = c.getText();
				val.add(sc);
			}
		}

		for (String s : Attributes) {
			int count = 0;
			for (String s1 : val) {
				if (s.equalsIgnoreCase(s1)) {
					System.out.println(s + " is present on webpage");
					break;
				} else {
					count += 1;
					if (count >= rows.size()) {
						System.out.println(s + " not found");
						break;
					}
					continue;
				}
			}
		}
	}

	public void MPMP_Related_Specifications() throws InterruptedException {

		List<String> Attributes = new ArrayList<String>();
		Attributes.add("Name");
		Attributes.add("Title");
		Attributes.add("Type");
		Attributes.add("State");
		Attributes.add("Artwork Primary");
		Attributes.add("Source");
		Attributes.add("Revision");
		Attributes.add("Description");
		Attributes.add("Specification");
		Attributes.add("SubType");
		Attributes.add("Originator");
		System.out.println("");
		System.out.println("************************Related Specifications **************************");
		System.out.println("");
		List<String> val = new ArrayList<String>();

		WebElement table = driver.findElement(By.id("collapseEight"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		int rsize = rows.size();
		for (int i = 0; i < rsize; i++) {
			List<WebElement> cols = rows.get(i).findElements(By.tagName("th"));
			for (WebElement c : cols) {
				String sc = c.getText();
				val.add(sc);
			}
		}
		for (String s : Attributes) {
			int count = 0;
			for (String s1 : val) {
				if (s.equalsIgnoreCase(s1)) {
					System.out.println(s + " is present on webpage");
					break;
				} else {
					count += 1;
					if (count >= rows.size()) {
						System.out.println(s + " not found");
						break;
					}
					continue;
				}
			}
		}
	}

	public void MPMP_Security_Classes() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("");
		System.out.println("***********************Secutrity Classes **************************");
		System.out.println("");
		if (driver.getPageSource().contains("Security Classes"))
			System.out.println();

		else {
			System.out.println();
			System.out.println("Security Classes is present in template but missing in webpage");
			System.out.println();
		}
	}

	public void MPMP_Files() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("");
		System.out.println("************************Files **************************");
		System.out.println("");
		if (driver.getPageSource().contains("Files"))
			System.out.println();

		else {
			System.out.println();
			System.out.println("Files is present in template but missing in webpage");
			System.out.println();
		}
	}

	public void MPMP_Reference_document() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("");
		System.out.println("************************Reference Document **************************");
		System.out.println("");
		if (driver.getPageSource().contains("Reference Document"))
			System.out.println();

		else {
			System.out.println();
			System.out.println("Reference Document is present in template but missing in webpage");
			System.out.println();
		}
	}

	public void MPMP_Substances_Materials() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("");
		System.out.println("************************Substances&Materials **************************");
		System.out.println("");
		if (driver.getPageSource().contains("Substances&Materials"))
			System.out.println();

		else {
			System.out.println();
			System.out.println("Substances & Materials is present in template but missing in webpage");
			System.out.println();
		}
	}

	public void MPMP_Performance_Characteristics() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("");
		System.out.println("************************Performance Characteristics **************************");
		System.out.println("");
		if (driver.getPageSource().contains("Performance Characteristics"))
			System.out.println();

		else {
			System.out.println();
			System.out.println("Performance Characteristics is present in template but missing in webpage");
			System.out.println();
		}
	}

	public void MPMP_Lifecycle() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("");
		System.out.println("************************Lifecycle/Aproval Powerview **************************");
		System.out.println("");
		if (driver.getPageSource().contains("Lifecycle/Aproval Powerview"))
			System.out.println();

		else {
			System.out.println();
			System.out.println("Lifecycle/Aproval Powerview is present in template but missing in webpage");
			System.out.println();
		}
	}

	public void MPMP_Organizations() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("");
		System.out.println("************************Organizations **************************");
		System.out.println("");
		if (driver.getPageSource().contains("Organizations"))
			System.out.println();

		else {
			System.out.println();
			System.out.println("Organizations is present in template but missing in webpage");
			System.out.println();
		}
	}

	public void afterClass() {
		System.out.println("");
		System.out.println("************************MPMP successfully completed **************************");
		System.out.println("");
	}

}
