package join;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class SEP {
	WebDriver driver;
	SoftAssert softassert=new SoftAssert();
	public SEP(WebDriver driver) {
		this.driver=driver;
	}
	
	//Attributes
	
	public void Attributes() throws InterruptedException {
		System.out.println("-------------------------------------------------------------------------------");
		System.out.println("VALIDATION OF SEP OBJECT...");
		System.out.println("**********************************  Attributes  ******************************");
		driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/div[3]/form/div[1]/input")).sendKeys("SEP");
		driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/div[3]/form/div[1]/div[2]/button/i")).click();
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"root\"]/div[2]/div/div[2]/div/div/div/div/table/tbody/tr[1]/td[1]/a/span")).click();
		Thread.sleep(10000);
		try {
		  	List<String>attribute=new ArrayList<String>();
			attribute.add("Title");
			attribute.add("Type");
			attribute.add("Originator");
			attribute.add("Description");
			attribute.add("Franchise");
			attribute.add("Revision");
			attribute.add("Originated");
			attribute.add("Owner");
			attribute.add("Release Date");
			attribute.add("Effective Date");
			attribute.add("Previous Revision Obsolete Date");
			attribute.add("Expiration Date");
			attribute.add("Reason for Change");
			attribute.add("Vendor");
			attribute.add("Vendor Number");
			attribute.add("Vendor Plant Location(Street Address Number)");
			attribute.add("Vendor Plant Location(Street Address Name)");
			attribute.add("Vendor Plant Location(City/Town)");
			attribute.add("Vendor Plant Location(State/Province)");
			attribute.add("Vendor Plant Location(Market)");
			attribute.add("Last Update User");
			attribute.add("Comments");
			attribute.add("Obsolete Date");
			attribute.add("Obsolete Comment");
			attribute.add("Material Restriction");
			attribute.add("Material Restriction Comment");
			attribute.add("Classification");
			
			



			WebElement t= driver.findElement(By.id("Zero"));
			List<WebElement>l=t.findElements(By.id("pageheaders"));
			for(String s:attribute) {
				int count=0;
				for(WebElement w:l) {
					String s1=w.getText();
					if(s.equalsIgnoreCase(s1)) {
						//org.testng.Assert.assertEquals(s1, s);
						Assert.assertEquals(s1, s);
						System.out.println(s+" is present on webpage");
						break;
					
					}

					else {
						count+=1;
						if(count>=l.size()) {
							System.out.println("Desc not in webpage");
							//org.testng.Assert.assertFalse(true);
							
						}
						
					continue;
					}
				}
				}
		}
		catch(Exception e) {
			System.out.println("Attributes in template but missing in webpage");
		}



		}

	//Reach
	
	public void REACH() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("**********************************  Reach  ******************************");
		if(driver.getPageSource().contains("REACH"))
			System.out.println();
		else {
			System.out.println();
			System.out.println("REACH is present in template but missing in webpage");
			System.out.println();
			}
	}

	//Materials & Composition
	
	public void MaterialsandComposition() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("********************************** Materials & Composition ******************************");
		if(driver.getPageSource().contains("Materials & Composition"))
			System.out.println();
		else {
			System.out.println();
			System.out.println("Materials & Composition is present in template but missing in webpage");
			System.out.println();
			}
	}

	//Related Specifications
	
	public void RelatedSpecifications() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("********************************** Related Specifications ******************************");
		if(driver.getPageSource().contains("Related Specifications"))
			System.out.println();
		else {
			System.out.println();
			System.out.println("Related Specifications is present in template but missing in webpage");
			System.out.println();
			}
	}

	//Reference Documents
	
	public void ReferenceDocuments() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("********************************** Reference Documents  ******************************");
		if(driver.getPageSource().contains("Reference Documents"))
			System.out.println();
		else {
			System.out.println();
			System.out.println("Reference Documents is present in template but missing in webpage");
			System.out.println();
			}
	}

	//Lifecycle/Approval Powerview
	
	public void LifecycleApprovalPowerview() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("**********************************Lifecycle/Approval Powerview ******************************");
		if(driver.getPageSource().contains("Lifecycle/Approval Powerview"))
			System.out.println();
		else {
			System.out.println();
			System.out.println("Lifecycle/Approval Powerview is present in template but missing in webpage");
			System.out.println();
			}
	}

	//Ownership
	
	public void Ownership() {
		System.out.println("********************************** Ownership ******************************");
		try {
	  	List<String>attribute=new ArrayList<String>();
		attribute.add("Originator");
		attribute.add("Segment");
		attribute.add("Co-Owners");
		attribute.add("Approvers");
		attribute.add("Last Update User");
		attribute.add("Last Update Date");
		

		WebElement t= driver.findElement(By.id("Six"));
		List<WebElement>l=t.findElements(By.id("pageheaders"));
		for(String s:attribute) {
			int count=0;
			for(WebElement w:l) {
				String s1=w.getText();
				if(s.equalsIgnoreCase(s1)) {
					//org.testng.Assert.assertEquals(s1, s);
					Assert.assertEquals(s1, s);
					System.out.println(s+" is present on webpage");
					break;
				
				}

				else {
					count+=1;
					if(count>=l.size()) {
						System.out.println("Desc not in webpage");
						//org.testng.Assert.assertFalse(true);
						
					}
					
				continue;
				}
			}
			}
		}
		catch(Exception e) {
			System.out.println("Ownership in template but missing in webpage");
		}



	}

	//IP classes
	
	public void IPclasses() {
		System.out.println("********************************** IP classes  ******************************");
		try {
	  	List<String>attribute=new ArrayList<String>();
		attribute.add("Name");
		attribute.add("Has Class Access?");
		attribute.add("Type");
		attribute.add("Description");
		attribute.add("State");
		
		
		
		
		List<String>plist=new ArrayList<String>();
		WebElement t= driver.findElement(By.id("Seven"));
		List<WebElement>rows=t.findElements(By.tagName("tr"));
		List<WebElement>cols=rows.get(1).findElements(By.tagName("th"));
		for(WebElement col :cols) {
			String ss =col.getText();
			plist.add(ss);
			System.out.println(ss);
		}


		for(String s:attribute) {
			int count=0;
			for(String w:plist) {
			//String s1=w.getText();
				if(s.equalsIgnoreCase(w)) {
					System.out.println(s+" is present on webpage");
					softassert.assertEquals(w, s);
				
			
				}

				else {
					count+=1;
					if(count>=plist.size()) {
						System.out.println(s+"Desc not in webpage");
					}
					continue;
				}
			}
		}
		softassert.assertAll();
		}
		catch(Exception e) {
			System.out.println("IPclasses in template but missing in webpage");
		}
		

	}

	//Security Classes
	
	public void SecurityClasses() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("********************************** Security Classes ******************************");
		if(driver.getPageSource().contains("Security Classes"))
			System.out.println();
		else {
			System.out.println();
			System.out.println("Security Classes is present in template but missing in webpage");
			System.out.println();
			}
	}

	//Enterprise Parts
	
	public void EnterpriseParts() {
		System.out.println("********************************** Enterprise Parts ***************************");
		  try {
	  	List<String>attribute=new ArrayList<String>();
		attribute.add("Name");
		attribute.add("Revision");
		attribute.add("Type");
		attribute.add("Description");
		attribute.add("State");
		attribute.add("PQRs");
		attribute.add("Name");
		attribute.add("State");
		attribute.add("Revision");
		


		List<String>plist=new ArrayList<String>();
		WebElement t= driver.findElement(By.id("Nine"));
		List<WebElement>rows=t.findElements(By.tagName("tr"));
		List<WebElement>cols=rows.get(1).findElements(By.tagName("th"));
		for(WebElement col :cols) {
			String ss =col.getText();
			plist.add(ss);
			System.out.println(ss);
		}


		for(String s:attribute) {
			int count=0;
			for(String w:plist) {
			//String s1=w.getText();
				if(s.equalsIgnoreCase(w)) {
					System.out.println(s+" is present on webpage");
					softassert.assertEquals(w, s);
				
			
				}

				else {
					count+=1;
					if(count>=plist.size()) {
						System.out.println(s+"Desc not in webpage");
					}
					continue;
				}
			}
		}
		softassert.assertAll();
			}
			catch(Exception e) {
				System.out.println("EnterpriseParts in template but missing in webpage");
			}
		

	}

	//Equivalent MEP

	public void EquivalentMEP() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("**********************************  Equivalent MEP  ******************************");
		if(driver.getPageSource().contains("Equivalent MEP"))
			System.out.println();
		else {
			System.out.println();
			System.out.println("Equivalent MEP is present in template but missing in webpage");
			System.out.println();
			}
	}

	//Certifications
	
	public void Certifications() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("********************************** Certifications  ******************************");
		if(driver.getPageSource().contains("Certifications"))
			System.out.println();
		else {
			System.out.println();
			System.out.println("Certifications is present in template but missing in webpage");
			System.out.println();
			}
	}

	//Organizations
	
	public void Organizations() {
		System.out.println("*********************************  Organizations  ******************************"); 
	  	try {
		List<String>attribute=new ArrayList<String>();
		attribute.add("Primary Organization");
		attribute.add("Secondary Organization");
		

		WebElement t= driver.findElement(By.id("Twelve"));
		List<WebElement>l=t.findElements(By.id("pageheaders"));
		for(String s:attribute) {
			int count=0;
			for(WebElement w:l) {
				String s1=w.getText();
				if(s.equalsIgnoreCase(s1)) {
					//org.testng.Assert.assertEquals(s1, s);
					Assert.assertEquals(s1, s);
					System.out.println(s+" is present on webpage");
					break;
				
				}

				else {
					count+=1;
					if(count>=l.size()) {
						System.out.println("Desc not in webpage");
						//org.testng.Assert.assertFalse(true);
						
					}
					
				continue;
				}
			}
			}
		}
		catch(Exception e) {
			System.out.println("Organizations in template but missing in webpage");
		}



	}

	//Files
	
	public void Files() {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("********************************** Files  ******************************");
		if(driver.getPageSource().contains("Files"))
			System.out.println();
		else {
			System.out.println();
			System.out.println("Files is present in template but missing in webpage");
			System.out.println();
			}
	}
	public void after() {
		System.out.println("****************************SEP COMPLETED SUCCESSFULLY**************************");
	}
}

