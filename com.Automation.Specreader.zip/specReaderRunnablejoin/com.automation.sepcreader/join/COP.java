package join;
import java.util.ArrayList;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
//import org.testng.annotations.AfterClass;
//import org.testng.annotations.BeforeClass;
//import org.testng.annotations.Test;
//import org.testng.asserts.Assertion;
import org.testng.asserts.SoftAssert;


public class COP {
	 WebDriver driver;
		public COP(WebDriver driver) {
			this.driver=driver;
		}
	 
	SoftAssert assertion=new SoftAssert();
public void beforeClass() throws InterruptedException{
 		
	System.out.println("");
	System.out.println("-------------------------------------------------------------------------------");
	System.out.println("VALIDATION OF COP OBJECT...");
	driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
 		Thread.sleep(5000);
 		driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/div[3]/form/div[1]/input")).sendKeys("COP");
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/div[3]/form/div[1]/div[2]/button/i")).click();
	      
	      Thread.sleep(2000);
	      System.out.println();
			System.out.println("______________________ COP OBJECT ___________________________");
			System.out.println();
	      if(driver.findElement(By.linkText("COP-00000005")).isDisplayed()) {
	    	  driver.findElement(By.linkText("COP-00000005")).click();
	      }
 		
 		Thread.sleep(1000);

 	}
  
  public void COP_Attribute() {
	  List<String> Attributes=new ArrayList<String>();
	  Attributes.add("Title");
	  Attributes.add("Specification Sub Type");
	  Attributes.add("Revision");
	  Attributes.add("Owner");
	  Attributes.add("Release Date");
	  Attributes.add("Previous Revision Obsolete Date");
	  Attributes.add("Product Dose Per Use UoM");
	  Attributes.add("Mode of Product Disposal");
	  Attributes.add("Base Unit Of Measure");
	  Attributes.add("Other Names");
	  Attributes.add("Packaging Size UoM");
	  Attributes.add("Obsolete Date");
	  Attributes.add("Description");
	  Attributes.add("Originator");
	  Attributes.add("Originated");
	  Attributes.add("Segment");
	  Attributes.add("Is Product Certification or Local");
	  Attributes.add("Standards Compliance Statement");
	  Attributes.add("Required");
	  Attributes.add("Expected Frequency of Use");
	  Attributes.add("Reason for Change");
	  Attributes.add("Alternative Unit Of Measure");
	  Attributes.add("Packaging Type");
	  Attributes.add("Comments");
	  Attributes.add("Obsolete Comment");
	  Attributes.add("Type");
	  Attributes.add("Last Update User");
	  Attributes.add("Phase");
	  Attributes.add("Structured Release Criteria Required");
	  Attributes.add("Expiration Date");
	  Attributes.add("Product Dose Per Use");
	  Attributes.add("Expected Frequency of Use UoM");
	  Attributes.add("Brand");
	  Attributes.add("Local Description");
	  Attributes.add("Packaging Size");
	  Attributes.add("Crush Index");
	  Attributes.add("Classification");
	  System.out.println("");
		System.out.println("************************ Attributes**************************");
		System.out.println("");
	  WebElement t= driver.findElement(By.id("collapseZero"));
	  List<WebElement> l=t.findElements(By.id("pageheaders"));
	  for(String s:Attributes) {
		  int count=0;
		  for(WebElement w:l) {
			  String s1=w.getText();
			  if(s.equalsIgnoreCase(s1)) {
				  Assert.assertEquals(s1,s);
				  System.out.println(s+ "  is present on webpage");
				  break;
			  }
			  else {
				  count+=1;
				  if(count>=l.size()) {
					  System.out.println(s+"is not there on webpage");
				  }
				  continue;
			  }
		  }
	  }
	  
	  
	  
  }
  
  public void COP_Weightcharacteristics() {
	  List<String> Attributes=new ArrayList<String>();
	  Attributes.add("Gross Weight:");
	  Attributes.add("Legacy Product Weight:");
	  Attributes.add("Legacy Weight Factor UoM:");
	  Attributes.add("Net Weight UoM:");
	  Attributes.add("Weight UoM:");
	  Attributes.add("Legacy Weight Factor:");
	  Attributes.add("Net Weight of Product In ConsumerUnit:");
	  System.out.println("");
		System.out.println("************************Weightcharacteristics  **************************");
		System.out.println("");
	 
	  
	  WebElement t= driver.findElement(By.id("collapseOne"));
	  List<WebElement> l=t.findElements(By.id("pageheaders"));
	  for(String s:Attributes) {
		  int count=0;
		  for(WebElement w:l) {
			  String s1=w.getText();
			  if(s.equalsIgnoreCase(s1)) {
				  Assert.assertEquals(s1,s);
				  System.out.println(s+ " is present on webpage");
				  break;
			  }
			  else {
				  count+=1;
				  if(count>=l.size()) {
					  System.out.println(s+"is not there on webpage");
				  }
				  continue;
			  }
		  }
	  }
  }
	  
	  public void COP_BillOfMaterials() {
		  List<String> Attributes=new ArrayList<String>();
	      Attributes.add("N");
	      Attributes.add("R");
	      Attributes.add("SP");      
	      Attributes.add("Alt");        
	      Attributes.add("OSPD");     
	      Attributes.add("DUOM");
	      System.out.println("");
			System.out.println("************************Bill Of Materials **************************");
			System.out.println("");
			try {
	      List<String>perfolist=new ArrayList<String>();
	      WebElement table =driver.findElement(By.xpath("//*[@id=\"collapseFour\"]/div/div/table/thead"));
	      List<WebElement>rows=table.findElements(By.tagName("tr"));
	      List<WebElement>cols=rows.get(0).findElements(By.tagName("th"));
	      for(WebElement col:cols){
	      String ss=col.getText();
	      perfolist.add(ss);}
	      List<String>p=new ArrayList<String>();
	      WebElement table2 =driver.findElement(By.xpath("//*[@id=\"collapseFour\"]/div/div/table/tbody/tr[1]"));
	      List<WebElement>rows2=table2.findElements(By.tagName("tr"));
	      List<WebElement>cols2=rows2.get(0).findElements(By.className("bomFontClass"));
	      for(WebElement col:cols2){
	    	  String ss=col.getText();
		      p.add(ss);}
		      for(String s:p){
		      for(String ss:s.split(":")){
		      perfolist.add(ss);}}
		      
		      for(String s:Attributes){
		      int count=0;
		      for(String s1:perfolist){
		      if(s.equalsIgnoreCase(s1)){
		      System.out.println(s +" present on webpage");
		      break;}
		      else{
		      count+=1;
		      if(count>=perfolist.size()){
		      System.out.println(s+" not found on webpage");}
		      continue;}}}
			}
			catch(Exception e) {
				System.out.println("COP_BillOfMaterials web element not found in webpage");
				System.out.println();
			}
	      }
	  
	  public void COP_Substitutes() {
		  List<String> Attributes=new ArrayList<String>();
	      Attributes.add("SP");
	      Attributes.add("REV");
	      Attributes.add("SCN");
	      Attributes.add("Title");
	      Attributes.add("T");
	      Attributes.add("SST");
	      Attributes.add("SF");
	      Attributes.add("REV");
	      Attributes.add("T");
	      Attributes.add("Ti");
	      Attributes.add("SST");
	      Attributes.add("OC");
	      System.out.println("");
			System.out.println("************************Substitutes  **************************");
			System.out.println("");
	      List<String>perfolist=new ArrayList<String>();
	      WebElement table =driver.findElement(By.xpath("/html/body/div/div[2]/div/div[2]/div[2]/div/div[4]/div[2]/div/div/table/thead"));
	      List<WebElement>rows=table.findElements(By.tagName("tr"));
	      List<WebElement>cols=rows.get(0).findElements(By.tagName("th"));
	      for(WebElement col:cols){
	      String ss=col.getText();
	      perfolist.add(ss);}
	      List<String>p=new ArrayList<String>();
	      WebElement table2 =driver.findElement(By.xpath("/html/body/div/div[2]/div/div[2]/div[2]/div/div[4]/div[2]/div/div/table/tbody"));
	      List<WebElement>rows2=table2.findElements(By.tagName("tr"));
	      List<WebElement>cols2=rows2.get(0).findElements(By.className("bomFontClass"));
	      for(WebElement col:cols2){
	      String ss=col.getText();
	      p.add(ss);}
	      for(String s:p){
	      for(String ss:s.split(":")){
	      perfolist.add(ss);}}
	      
	      for(String s:Attributes){
	      int count=0;
	      for(String s1:perfolist){
	      if(s.equalsIgnoreCase(s1)){
	      System.out.println(s +" present on webpage");
	      break;}
	      else{
	      count+=1;
	      if(count>=perfolist.size()){
	      System.out.println(s+" not found on webpage");}
	      continue;}}}}
	  
		public void COP_lifecycle() throws InterruptedException {
			
			Thread.sleep(5000);
			List<String>life=new ArrayList<String>();
			life.add("Tasks/Signatures");
			life.add("Name");
			life.add("Approver");
			life.add("Title");
			life.add("Approval Status");
			life.add("Approval/Due Date");
			life.add("Comments/Instructions");
			 System.out.println("");
				System.out.println("************************Lifecycle  **************************");
				System.out.println("");
			List<String>val=new ArrayList<String>();
		
		WebElement ltable=driver.findElement(By.id("collapseElevan"));
			List<WebElement>rows=ltable.findElements(By.tagName("tr"));
			int rsize=rows.size();
			for(int i=0;i<rsize;i++) {
				List<WebElement>cols=rows.get(i).findElements(By.tagName("th"));
				for(WebElement c:cols) {
					String sc=c.getText();
					val.add(sc);
					System.out.println(sc);
				}
			}
			
			for(String s:life) {
				int count=0;
				for(String w:val) {
					if(s.equalsIgnoreCase(w)) {
						System.out.println(s+" is present on webpage");
						break;}
						else {
							count+=1;
							if(count>=val.size()) {
								System.out.println(s+" not in webpage");
							}

							continue;
						}
					}
				}
}
			
			public void COP_Ownership() {
				List<String>Ownership=new ArrayList<String>();
				Ownership.add("Originator");
				Ownership.add("Co-Owners");
				Ownership.add("Last Update User");
				Ownership.add("Segment");
				Ownership.add("Approvers");
				Ownership.add("Last Update Date");
				 System.out.println("");
					System.out.println("************************Ownership **************************");
					System.out.println("");
				List<String>ownerlist=new ArrayList<String>();
				WebElement table=driver.findElement(By.id("collapseTwelve"));
				List<WebElement>cols=table.findElements(By.id("pageheaders"));
				for(WebElement c:cols) {
					String ss2=c.getText();
					ownerlist.add(ss2);
					System.out.println(ss2);
}
				for(String s:Ownership) {
					int count=0;
					for(String w:ownerlist) {
						
						if(s.equalsIgnoreCase(w)) {
							System.out.println(s+" is present on webpage");	
							break;
						}
						else {
							count+=1;
							if(count>=ownerlist.size()) {
								System.out.println(s+" not in webpage");
							}
							continue;
						}
					}
				}
			}
			
			public void COP_IPClasses() {
				List<String>IPclasses=new ArrayList<String>();
				IPclasses.add("Name");
				IPclasses.add("Has Class Access?");
				IPclasses.add("Type");
				IPclasses.add("Description");
				IPclasses.add("State");
				 System.out.println("");
					System.out.println("*********************IP Classes  **************************");
					System.out.println("");
				List<String>IPclass=new ArrayList<String>();
				WebElement table=driver.findElement(By.id("collapseThirteen"));
				List<WebElement>cols=table.findElements(By.tagName("th"));
				for(WebElement c:cols) {
					String ss2=c.getText();
					IPclass.add(ss2);
					System.out.println(ss2);
				}
				for(String s:IPclasses) {
					int count=0;
					for(String w:IPclass) {
						
						if(s.equalsIgnoreCase(w)) {
							System.out.println(s+" is present on webpage");	
							break;
						}
						else {
							count+=1;
							if(count>=IPclass.size()) {
								System.out.println(s+" not in webpage");
							}
							continue;
						}
					}
				}}
			 
			  public void COP_Organizations() {
				   
						List<String>organizations=new ArrayList<String>();
						organizations.add("Primary Organization");
						organizations.add("Secondary Organization");
						 System.out.println("");
							System.out.println("************************Organizations  **************************");
							System.out.println("");
						List<String>organ=new ArrayList<String>();
						WebElement table=driver.findElement(By.id("collapseSixteen"));
						List<WebElement>cols=table.findElements(By.id("pageheaders"));
						for(WebElement r:cols) {
							String ss=r.getText();
							organ.add(ss);
							System.out.println(ss);
						}
						for(String s:organizations) {
							int count=0;
							for(String w:organ) {
								
								if(s.equalsIgnoreCase(w)) {
									System.out.println(s+" is present on webpage");	
									break;
							}
								else {
									count+=1;
									if(count>=organ.size()) {
										System.out.println(s+" not in webpage");
									}
									continue;
								}
								
							  }
							  }}
	
	public void COP_Reference_Documents() throws InterruptedException {
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  System.out.println("");
		System.out.println("************************Reference Documents  **************************");
		System.out.println("");
			if(driver.getPageSource().contains("Reference Documents")) {
			    System.out.println();}
			else {
				System.out.println();
				System.out.println("Reference Documents is present in template but missing in webpage");
				
				System.out.println();
				
				
			}
	}
	
	public void COP_Performance_Characterstics() throws InterruptedException {
	 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	 System.out.println("");
		System.out.println("************************Performance Characteristics  **************************");
		System.out.println("");
	if(driver.getPageSource().contains("Performance_Characterstics")) {
	    System.out.println();}
	else {
		System.out.println();
		System.out.println("Performance_Characterstics is present in template but missing in webpage");
		
		System.out.println();
		
		
	}
	}
	
	public void COP_Plants() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 System.out.println("");
			System.out.println("************************Plants  **************************");
			System.out.println("");
		if(driver.getPageSource().contains("Plants")) {
		    System.out.println();}
		else {
			System.out.println();
			System.out.println("Plants is present in template but missing in webpage");
			
			System.out.println();
			
			
		}
	}
	
	public void COP_DerivedTo() throws InterruptedException {
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 System.out.println("");
			System.out.println("************************Derived To  **************************");
			System.out.println("");
			if(driver.getPageSource().contains(" Derived To")) {
			    System.out.println();}
			else {
				System.out.println();
				System.out.println("Derived To is present in template but missing in webpage");
				
				System.out.println();
				
				
			}
	}
	
	public void COP_Security_Classes() throws InterruptedException {
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 System.out.println("");
			System.out.println("************************Security Classes  **************************");
			System.out.println("");
			if(driver.getPageSource().contains("Security Classes")) {
			    System.out.println();}
			else {
				System.out.println();
				System.out.println("Security Classes is present in template but missing in webpage");
				
				System.out.println();
				
				
			}
	}
	
	public void COP_Related_ATS() throws InterruptedException {
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 System.out.println("");
			System.out.println("************************Related ATS  **************************");
			System.out.println("");
			if(driver.getPageSource().contains("Related ATS")) {
			    System.out.println();}
			else {
				System.out.println();
				System.out.println("Related ATS is present in template but missing in webpage");
				
				System.out.println();
				
				
			}
	}
	
	public void COP_Files() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 System.out.println("");
			System.out.println("************************Files  **************************");
			System.out.println("");
		if(driver.getPageSource().contains("Files")) {
		    System.out.println();}
		else {
			System.out.println();
			System.out.println("Files are present in template but not there in webpage");
			
			System.out.println();
			
			
		}
	}
	
	public void COP_RelatedSpecifications() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 System.out.println("");
			System.out.println("**********************Related Specifications  **************************");
			System.out.println("");
		if(driver.getPageSource().contains("Related Specifications")) {
		    System.out.println();}
		else {
			System.out.println();
			System.out.println("Related Specifications  is presnt in template but not present in webpage");
			
			System.out.println();
			
			
		}
	}
	
	public void COP_Master_Specifications() throws InterruptedException {

		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  System.out.println("");
			System.out.println("***********************Master Specifications  **************************");
			System.out.println("");
		if(driver.getPageSource().contains("Master Specifications")) {
		    System.out.println();}
		else {
			System.out.println();
			System.out.println("Master Specifications is present in template but  not present in webpage");
			
			System.out.println();
			
			
		}
	}
	
	public void COP_Notes() throws InterruptedException {

		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  System.out.println("");
			System.out.println("************************Notes  **************************");
			System.out.println("");
		if(driver.getPageSource().contains("Notes")) {
		    System.out.println();}
		else {
			System.out.println();
			System.out.println("Notes is presnt in template but  not present in webpage");
			
			System.out.println();
			
			
		}
	}
	
	      
	     
	  
   
 		
 		public void AfterClass() {
 			 System.out.println("");
 			System.out.println("************************COP Successfully completed  **************************");
 			System.out.println("");
 			
 		}
 		

 		
 



  }


 

