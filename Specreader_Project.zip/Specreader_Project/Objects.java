package join;

import org.openqa.selenium.WebDriver;

public class Objects {
	WebDriver driver;

	public Objects(WebDriver driver) {
		this.driver = driver;
	}

	public void ARMP() throws Exception {
		ARMP armp = new ARMP(driver);
		armp.Attribute();
		armp.Plants();
		armp.PQR_View_Manufacturer_Equivalents();
		armp.Lifecycle_Approval_Powerview();
		armp.IP_Classes();
		armp.Organizations();
		armp.Materials_Composition();
		armp.Related_Specifications();
		armp.Master_Specifications();
		armp.Performance_Charcteristic();
		armp.PQR_View_Supplier_Equivalents();
		armp.Security_Classes();
		armp.Files();
		armp.After();
	}

	public void DPP() throws Exception {
		DPP dpp = new DPP(driver);
		dpp.Attribute();
		dpp.Weight_Caracteristics();
		dpp.Storage_Transportation_Labeling_Assessment_Data();
		dpp.MarketClearance();
		dpp.Materials_Composition();
		dpp.Plants();
		dpp.Lifecycle_Approval_Powerview();
		dpp.Ownership();
		dpp.IP_Classes();
		dpp.Organizations();
		dpp.Dangerous_Goods_Classification();
		dpp.Global_Harmonized_Standard();
		dpp.Product_Part_Stability_Document();
		dpp.Master_Part_Stability_Document();
		dpp.Notes();
		dpp.SAP_BOM_as_Fed();
		dpp.Bill_of_Materials();
		dpp.Substitues();
		dpp.Related_Specifications();
		dpp.Master_Specifications();
		dpp.Reference_Documents();
		dpp.Performance_Charcteristic();
		dpp.PQR_View_Manufacturer_Equivalents();
		dpp.PQR_View_Supplier_Equivalents();
		dpp.Material_Produced();
		dpp.Security_Classes();
		dpp.Related_ATS();
		dpp.Files();
		dpp.Certifications();
		dpp.After();
	}

	public void OPP() throws Exception {
		OPP opp = new OPP(driver);
		opp.Attribute();
		opp.Related_Specifications();
		opp.Plants();
		opp.Ownership();
		opp.IP_Classes();
		opp.Organizations();
		opp.Lifecycle_Approval_Powerview();
		opp.Substances_Materials();
		opp.Materials_Composition();
		opp.Master_Specifications();
		opp.Reference_Documents();
		opp.Performance_Charcteristic();
		opp.PQR_View_Manufacturer_Equivalents();
		opp.PQR_View_Supplier_Equivalents();
		opp.Security_Classes();
		opp.Files();
		opp.After();
	}

	public void APMP() throws Exception {
		APMP apmp = new APMP(driver);
		apmp.attributes();
		apmp.Weight_Characteristic();
		apmp.ipclass();
		apmp.lifecycle_approval_review();
		apmp.ownership();
		apmp.plants();
		apmp.organizations();
		apmp.substance_materials();
		apmp.Notes();
		apmp.RelatedSpecifications();
		apmp.ReferenceDocuments();
		apmp.SecurityClasses();
		apmp.Files();
		apmp.After();
	}

	public void APP() throws Exception {
		APP app = new APP(driver);
		app.attributes();
		app.Weight_Characteristic();
		app.Storage_Transportation_Labeling_Assessment_Data();
		app.Related_specification();
		app.Plants();
		app.lifecycle_approval_review();
		app.ownership();
		app.ipclass();
		app.organizations();
		app.Performance_Characteristic();
		app.billOfMaterials();
		app.substitutes();
		app.Files();
		app.MarketClearance();
		app.SAPBOMasFed();
		app.DangerousGoodsClassification();
		app.GlobalHarmonizedStandard();
		app.Notes();
		app.ProductPartStabilityDocument();
		app.MasterPartStabilityDocument();
		app.MaterialComposition();
		app.MasterSpecifications();
		app.ReferenceDocuments();
		app.Alternates();
		app.SecurityClasses();
		app.RelatedATS();
		app.Certifications();
		app.After();
	}

	public void MEP() throws Exception {
		MEP mep = new MEP(driver);
		mep.attributes();
		mep.ownership();
		mep.ipclass();
		mep.organizations();
		mep.Enterprise_parts();
		mep.REACH();
		mep.Materials_and_composition();
		mep.Related_Specifications();
		mep.ReferenceDocuments();
		mep.Lifecyle_approval_preview();
		mep.Security_Classes();
		mep.Equivalent_sep();
		mep.Certifications();
		mep.Files();
		mep.After();
	}

	public void MIP() throws Exception {
		MIP mip = new MIP(driver);
		mip.attributes();
		mip.lifecycle_approval_review();
		mip.ownership();
		mip.ipclass();
		mip.organizations();
		mip.Performance_Characteristic();
		mip.Notes();
		mip.BillOfMaterials();
		mip.RelatedSpecifications();
		mip.ReferenceDocuments();
		mip.SecurityClasses();
		mip.Files();
		mip.Substitutes();
		mip.Lifecyle_approval_preview();
		mip.After();
	}

	public void FOP() throws Exception {
		FOP fop = new FOP(driver);
		fop.beforeClass();
		fop.FOP_Attributes();
		fop.FOP_Certifications();
		fop.FOP_Chemicals();
		fop.FOP_Chemicals_Enguinityl();
		fop.FOP_Chemicals_Warehouse();
		fop.FOP_Files();
		fop.FOP_Formulation();
		fop.FOP_Formulation_Formula();
		fop.FOP_Global();
		fop.FOP_Goods_Classification();
		fop.FOP_IPClasses();
		fop.FOP_lifecycle();
		fop.FOP_Market();
		fop.FOP_Master_Part();
		fop.FOP_Master_Specifications();
		fop.FOP_Materials();
		fop.FOP_Materials_Produced();
		fop.FOP_Organizations();
		fop.FOP_Ownership();
		fop.FOP_Performance_Characteristics();
		fop.FOP_Plants();
		fop.FOP_Product();
		fop.FOP_Product_Part();
		fop.FOP_Reference();
		fop.FOP_Related();
		fop.FOP_Related_ATS();
		fop.FOP_SAP();
		fop.FOP_Security_Classes();
		fop.FOP_Storage();
		fop.FOP_Substitutes();
		fop.FOP_Weightcharacteristics();
		fop.afterClass();
	}
	
	public void FPP() throws Exception{
		FPP fpp= new FPP(driver);
		fpp.beforeClass();
		fpp.FPP_Attributes();
		fpp.FPP_storage_transport_labelling();
		fpp.FPP_warehouse_classification();
		fpp.FPP_sapBomfed();
		fpp.FPP_BoM();
		fpp.FPP_BoM_Customer();
		fpp.FPP_BoM_Consumer();
		fpp.FPP_substitutes();
		fpp.FPP_BoM_Transport();
		fpp.FPP_BoM_Master_Customer();
		fpp.FPP_BoM_Master_Consumer();
		fpp.FPP_Master_Specifications();
		fpp.FPP_performanceCharacteristic();
		fpp.FPP_Market_Of_Sales();
		fpp.FPP_Plants();
		fpp.FPP_lifecycle();
		fpp.FPP_Ownership();
		fpp.FPP_IPClasses();
		fpp.FPP_Weights_Dimensions();
		fpp.FPP_packaging_unit();
		fpp.FPP_transport_unit();
		fpp.FPP_Organizations();
		fpp.FPP_Goods_Classification();
		fpp.FPP_Global();
		fpp.FPP_Notes();
		fpp.FPP_Stability();
		fpp.FPP_BOM_innerpack();
		fpp.FPP_Substitutesinner();
		fpp.FPP_SubstitutesTransport();
		fpp.FPP_Substitutesmasterconsumer();
		fpp.FPP_Related_Specifications();
		fpp.FPP_Reference_Documents();
		fpp.FPP_Related_ATS();
		fpp.FPP_Certifications();
		fpp.FPP_Files();
		fpp.afterClass();
	
	}

	public void COP() throws Exception {
		COP cop = new COP(driver);
		cop.beforeClass();
		cop.COP_Attribute();
		cop.COP_Weightcharacteristics();
		cop.COP_Substitutes();
		cop.COP_DerivedTo();
		cop.COP_Files();
		cop.COP_IPClasses();
		cop.COP_lifecycle();
		cop.COP_Master_Specifications();
		cop.COP_Notes();
		cop.COP_Organizations();
		cop.COP_Ownership();
		cop.COP_Performance_Characterstics();
		cop.COP_Plants();
		cop.COP_Reference_Documents();
		cop.COP_Related_ATS();
		cop.COP_RelatedSpecifications();
		cop.COP_Security_Classes();
		cop.AfterClass();

	}

	public void MPP() throws Exception {
		MPP mpp = new MPP(driver);
		mpp.beforeClass();
		mpp.MPP_Attribute();
		mpp.MPP_Bill_of_Materials();
		mpp.MPP_Files();
		mpp.MPP_IPClasses();
		mpp.MPP_lifecycle();
		mpp.MPP_Notes();
		mpp.MPP_Organizations();
		mpp.MPP_Ownership();
		mpp.MPP_Performancecharacteristics();
		mpp.MPP_Reference_Documents();
		mpp.MPP_Related_Specifications();
		mpp.MPP_Security_Classes();
		mpp.MPP_Stability_Document();
		mpp.MPP_Substitutes();
		mpp.afterClass();
	}

	public void CUP() throws Exception {
		CUP cup = new CUP(driver);
		cup.attributes();
		cup.billOfMaterials();
		cup.files();
		cup.ipclass();
		cup.lifeCycle();
		cup.masterSpecification();
		cup.notes();
		cup.organizations();
		cup.ownership();
		cup.performanceCharacteristic();
		cup.plants();
		cup.referenceDocuments();
		cup.relatedATS();
		cup.relatedSpecification();
		cup.Storage();
		cup.substitutes();
		cup.weightCharacteristics();

	}

	public void FAB() throws Exception {
		FAB fab = new FAB(driver);
		fab.attribute();
		fab.billOfMaterials();
		fab.files();
		fab.ipclass();
		fab.lifeCycle();
		fab.marketOfSale();
		fab.masterSpecification();
		fab.notes();
		fab.organizations();
		fab.ownership();
		fab.performanceCharacteristic();
		fab.plants();
		fab.pqrViewManufacturer();
		fab.pqrViewSupplier();
		fab.referenceDocuments();
		fab.relatedATS();
		fab.relatedSpecification();
		fab.substancesMaterials();
		fab.substitutes();
		fab.sapBomfed();
		fab.securityClasses();
		fab.weightCharacteristics();

	}

	public void PAP() throws Exception {
		PAP pap = new PAP(driver);
		pap.attributes();
		pap.billOfMaterials();
		pap.files();
		pap.ipclass();
		pap.lifeCycle();
		pap.marketOfSale();
		pap.masterSpecification();
		pap.notes();
		pap.organizations();
		pap.ownership();
		pap.performanceCharacteristic();
		pap.plants();
		pap.pqrViewManufacturerEquivalents();
		pap.pqrViewSupplierEquivalents();
		pap.referenceDocuments();
		pap.relatedATS();
		pap.relatedSpecification();
		pap.sapBom();
		pap.securityClasses();
		pap.substitutes();
		pap.weightCharacteristics();
	}

	public void MPAP() throws Exception {
		MPAP mpap = new MPAP(driver);
		mpap.attributes();
		mpap.billOfMaterials();
		mpap.files();
		mpap.ipclass();
		mpap.lifeCyle();
		mpap.notes();
		mpap.organizations();
		mpap.ownership();
		mpap.performanceCharacteristic();
		mpap.referenceDocuments();
		mpap.relatedSpecifications();
		mpap.securityClasses();
		mpap.substitutes();
	}

	public void MRMP() throws Exception {
		MRMP mrmp = new MRMP(driver);
		mrmp.atrributes();
		mrmp.relatedSpecification();
		mrmp.refernceDocument();
		mrmp.ownership();
		mrmp.IPCLass();
		mrmp.Organization();
		mrmp.performance_Characteristic();
		mrmp.lifecycle();
		mrmp.securityClasses();
		mrmp.Files();
		mrmp.After();
		

	}

	public void IP() throws Exception {
		IP ip = new IP(driver);
		ip.attributes();
		ip.weight_Characteristic();
		ip.bill_of_materials();
		ip.ownership();
		ip.IPCLass();
		ip.lifecycle();
		ip.securityClasses();
		ip.performancecharacteristic();
		ip.Files();
		ip.relatesSpecification();
		ip.masterSpecification();
		ip.organization();
		ip.Realtedats();
		ip.refernecedocument();
		ip.subtitutes();
		ip.note();
		ip.note();
		

	}

	public void PIP() throws Exception {
		PIP pip = new PIP(driver);
		pip.attributes();
		pip.weight_Characteristic();
		pip.Plants();
		pip.lifecycle();
		pip.ownership();
		pip.IPCLass();
		pip.Organization();
		pip.refernecedocument();
		pip.relatesSpecification();
		pip.securityClasses();
		pip.Files();
		pip.performancecharacteristic();
		pip.PQR_View_Supplier_Equivalents();
		pip.PQR_View_manufacturer_Equivalents();
		pip.After();
		
	}
	
	public void RMP() throws Exception{
		RMP rmp= new RMP(driver);
		rmp.beforeClass();
		rmp.Alternates();
		rmp.Attributes();
		rmp.Certifications();
		rmp.Chemical_Classification();
		rmp.Chemical_Properties();
		rmp.Detergent_Properties();
		rmp.IP_Classes();
		rmp.Lifecycle();
		rmp.Master_Specifications();
		rmp.Materials_comp();
		rmp.Organizations();
		rmp.Ownership();
		rmp.Performance_Characteristic();
		rmp.Perfume_Properties();
		rmp.Physical_Properties();
		rmp.PQR_View1();
		rmp.PQR_View2();
		rmp.Producing_Formula();
		rmp.Profile();
		rmp.RD_Sites();
		rmp.Reference_document();
		rmp.Related_ATS();
		rmp.Related_Specifications();
		rmp.Security_Classes();
		rmp.Sites();
		rmp.Stability_document();
		rmp.Starting_Materials();
		rmp.Weight_Caracteristics();
		
		
		rmp.afterClass();
	}
	public void PMP() throws Exception{
		PMP pmp=new PMP(driver);
		pmp.beforeClass();
		pmp.Attributes();
		pmp.Files();
		pmp.IP_Classes();
		pmp.Lifecycle();
		pmp.Master_Specifications();
		pmp.Organizations();
		pmp.Ownership();
		pmp.Performance_Characteristics();
		pmp.Plants();
		pmp.PQR_View1();
		pmp.PQR_View2();
		pmp.Reference_Documents();
		pmp.Related_ATS();
		pmp.Related_Specifications();
		pmp.Security_Classes();
		pmp.Substance_Materials();
		pmp.Weight_Caracteristics();
		pmp.afterClass();
	}
	public void MPMP() throws Exception{
		MPMP mpmp= new MPMP(driver);
		mpmp.beforeClass();
		mpmp.MPMP_Attributesvalidate();
		mpmp.MPMP_Files();
		mpmp.MPMP_IP_Classes();
		mpmp.MPMP_Lifecycle();
		mpmp.MPMP_Organizations();
		mpmp.MPMP_Ownership();
		mpmp.MPMP_Performance_Characteristics();
		mpmp.MPMP_Reference_document();
		mpmp.MPMP_Related_Specifications();
		mpmp.MPMP_Security_Classes();
		mpmp.MPMP_Substances_Materials();
		mpmp.afterClass();
	}
	
	public void IRMS() throws Exception{
		IRMS irms = new IRMS(driver);
		irms.Attributes();
		irms.ProfileIdentification();
		irms.PhysicalProperties();
		irms.PerfumeProperties();
		irms.ChemicalMolecularProperties();
		irms.DetergentSurfuctantProperties();
		irms.WeightCharacteristic();
		irms.ChemicalClassification();
		irms.REACH();
		irms.StabilityDocument();
		irms.MaterialsandComposition();
		irms.SubstancesandMaterials();
		irms.Alternates();
		irms.RelatedSpecifications();
		irms.MasterSpecifications();
		irms.ReferenceDocuments();
		irms.PerformanceCharacteristic();
		irms.PlantsIFHALB();
		irms.Plants();
		irms.PQRViewManufacturerEquivalents();
		irms.PQRViewSupplierEquivalents();
		irms.LifecycleApprovalPowerview();
		irms.Ownership();
		irms.IPclasses();
		irms.SecurityClasses();
		irms.RegulatoryandSafetyData();
		irms.ProducingFormula();
		irms.RelatedATS();
		irms.RandDSites();
		irms.Organizations();
		irms.afterClass();
		
		
		
	}
public void MCOP() throws Exception{
	MCOP mcop = new MCOP(driver);
	mcop.Attributes();
	mcop.Notes();
	mcop.BillofMaterials();
	mcop.Substitutes();
	mcop.RelatedSpecifications();
	mcop.ReferenceDocuments();
	mcop.PerformanceCharacteristics();
	mcop.LifecycleApprovalPowerview();
	mcop.Ownership();
	mcop.IPclasses();
	mcop.SecurityClasses();
	mcop.Organizations();
	mcop.Files();
	mcop.after();
		
	}
public void SEP() throws Exception{
	SEP sep =new SEP(driver);
	sep.Attributes();
	sep.REACH();
	sep.MaterialsandComposition();
	sep.RelatedSpecifications();
	sep.ReferenceDocuments();
	sep.LifecycleApprovalPowerview();
	sep.Ownership();
	sep.IPclasses();
	sep.SecurityClasses();
	sep.EnterpriseParts();
	sep.EquivalentMEP();
	sep.Certifications();
	sep.Organizations();
	sep.Files();
	sep.after();
	
	
}
public void TUP() throws Exception{
	TUP tup = new TUP(driver);
	tup.beforeClass();
	tup.Attributes();
	tup.Notes();
	tup.BillofMaterials();
	tup.Substitutes();
	tup.BillofMaterialsMasterConsumerUnit();
	tup.BillofMaterialsMasterInnerPack();
	tup.SubstitutesMasterInnerPack();
	tup.BillofMaterialsMasterCustomerUnit();
	tup.RelatedSpecifications();
	tup.ReferenceDocuments();
	tup.LifecycleApprovalPowerview();
	tup.Ownership();
	tup.IPclasses();
	tup.SecurityClasses();
	tup.RelatedATS();
	tup.Organizations();
	tup.Files();
	tup.afterClass();
	
}
public void MCUP() throws Exception{
	MCUP mcup = new MCUP(driver);
	mcup.Attributes();
	mcup.Notes();
	mcup.RelatedSpecifications();
	mcup.ReferenceDocuments();
	mcup.PerformanceCharacteristics();
	mcup.LifecycleApprovalPowerview();
	mcup.Ownership();
	mcup.IPclasses();
	mcup.SecurityClasses();
	mcup.Organizations();
	mcup.Files();
	mcup.after();
	
}
	
}
