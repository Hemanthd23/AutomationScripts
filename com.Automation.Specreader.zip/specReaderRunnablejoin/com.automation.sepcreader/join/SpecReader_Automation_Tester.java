package join;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SpecReader_Automation_Tester {
	public static void main(String[] args) throws Exception {
		System.out.println("--------------------------------------------------------------------");
		System.out.println("           Welcome To SpecReader WebPage Testing        ");
		System.out.println("--------------------------------------------------------------------");
		SpecReader_Automation_Tester test = new SpecReader_Automation_Tester();
		test.test();
	}

	@Test
	public void test() throws Exception {
		System.out.println("Web Page Login");
		System.setProperty("webdriver.chrome.driver", "D:\\Infy Artifacts\\chromedriver_win32 (1)\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://specsqaap.pg.com/login");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.findElement(By.id("username")).sendKeys("Anywheretwo.im");
		driver.manage().timeouts().implicitlyWait(2000, TimeUnit.SECONDS);
		driver.findElement(By.id("password")).sendKeys("Sa121620");
		driver.manage().timeouts().implicitlyWait(50000, TimeUnit.SECONDS);
		driver.findElement(By.id("loginButton")).click();
		driver.manage().timeouts().implicitlyWait(50000, TimeUnit.SECONDS);
		
		Objects obj = new Objects(driver);
		obj.ARMP();
		obj.APMP();
		obj.APP();
		obj.COP();
		obj.CUP();
		obj.DPP();
		obj.FAB();
		obj.FOP();
		obj.IP();
		obj.IRMS();
		obj.MCOP();
		obj.MCUP();
		obj.MEP();
		obj.MIP();
		obj.MPAP();
		obj.MPMP();
		obj.MPP();
		obj.MRMP();
		obj.OPP();
		obj.PAP();
		obj.PIP();
		obj.PMP();
		obj.RMP();
		obj.SEP();
		obj.TUP();
		
		
		
		System.out.println("--------------------------------------------------------------------");
		System.out.println("              SpecReader WebPage Tested Successfully        ");
		System.out.println("--------------------------------------------------------------------");
		driver.quit();
	}

}
