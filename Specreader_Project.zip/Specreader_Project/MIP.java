package join;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
/*------------  Object Name	: MIP   ---------*******
 * -----------	Name		: MIP-00000009----------*****
 * ----------	Number of Test Cases Pass : 6 -------------
 * ----------	Number of Test Cases Fail : 8 -------------
 */
public class MIP {
WebDriver driver;
	public MIP(WebDriver driver) {
		
		this.driver=driver;
	}

		public void attributes() {
			System.out.println("");
			System.out.println("-------------------------------------------------------------------------------");
			System.out.println("VALIDATION OF MIP OBJECT...");
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
			driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/div[3]/form/div[1]/input")).sendKeys("MIP");
			driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
										   
			driver.findElement(By.xpath("//*[@id=\"root\"]/div[1]/div[1]/div[3]/form/div[1]/div[2]/button/i")).click();
			driver.manage().timeouts().implicitlyWait(150, TimeUnit.SECONDS);
										  //*[@id="root"]/div[2]/div/div[2]/div/div/div/div/table/tbody/tr[2]/td[1]/a
			driver.findElement(By.xpath("//*[@id=\"root\"]/div[2]/div/div[2]/div/div/div/div/table/tbody/tr[2]/td[1]/a")).click();			
			System.out.println("---------MIP-----------");
			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[1]/div[1]/div")).isDisplayed())
									//			if(d.findElement(By.linkText("Attributes")).isDisplayed())
				{
					System.out.println("");
					System.out.println("**********Attributes***************");
					System.out.println("");
					List<String>attribute=new ArrayList<String>();
					attribute.add("Description");
					attribute.add("Title");
					attribute.add("Originator");
					attribute.add("Last Update User");
					attribute.add("Type");
					attribute.add("Revision");
					attribute.add("Originated");
					attribute.add("Phase");
					attribute.add("Owner");
					attribute.add("Segment");
					attribute.add("Structured Release Criteria Required");
					attribute.add("Release Date");
					attribute.add("Effective Date");
					attribute.add("Expiration Date");
					attribute.add("Previous Revision Obsolete Date");
					attribute.add("Reason for Change");
					attribute.add("Dimension Unit of Measure");
					attribute.add("Outer Dimension Width");
					attribute.add("Outer Dimension Depth");
					attribute.add("Outer Dimension Height");
					attribute.add("Comments");
					attribute.add("Obsolete Date");
					attribute.add("Obsolete Comment");
					attribute.add("Project Initiative MileStone");
					attribute.add("Classification");
					attribute.add("Other Names");
					List<WebElement>alist=driver.findElements(By.id("pageheaders"));
					for(String s:attribute) {
						int count=0;
						for(WebElement w:alist) {
							String s1=w.getText();
							if(s.equalsIgnoreCase(s1)) {
								System.out.println(s+" is present on webpage");	
								break;
							}
							else {
								count+=1;
								if(count>=alist.size()) {
									System.out.println(s+" not in webpage");
								}
								continue;
							}
						}
					}

				}
			}
			catch(Exception e) {
				System.out.println("Attributes web element not found in webpage");
				System.out.println(e.getMessage());
			}
		}
		
		public void lifecycle_approval_review() {
			System.out.println("\n");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[3]/div[1]/div")).isDisplayed())
					
					//			if(d.findElement(By.linkText("Lifecycle/Approval Powerview")).isDisplayed())
				{
					System.out.println("****************lifecycle approval review -***************");
					List<String>life=new ArrayList<String>();
					life.add("Tasks/Signatures");
					life.add("Name");
					life.add("Approver");
					life.add("Title");
					life.add("Approval Status");
					life.add("Approval/Due Date");
					life.add("Comments/Instructions");

					List<String>val=new ArrayList<String>();
					WebElement lifetable=driver.findElement(By.xpath("//*[@id=\"seven\"]"));
					List<WebElement>rows=lifetable.findElements(By.tagName("tr"));
					int rsize=rows.size();
					for(int i=0;i<rsize;i++) {
						List<WebElement>cols=rows.get(i).findElements(By.tagName("th"));
						for(WebElement c:cols) {
							String sc=c.getText();
							val.add(sc);
							//System.out.println(sc);
						}
					}

					for(String s:life) {
						int count=0;
						for(String w:val) {
							if(s.equalsIgnoreCase(w)) {
								System.out.println(s+" is present on webpage");
								break;
							}
							else {
								count+=1;
								if(count>=val.size()) {
									System.out.println(s+" not in webpage");
								}

								continue;
							}
						}
					}
				}
			}
			catch(Exception e) {
				System.out.println("Lifecycle/Approval Powerview web element not found in webpage");
				System.out.println();
			}
		}
		
		public void ownership() {
			System.out.println("\n");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[4]/div[1]/div")).isDisplayed())
					
					//			if(d.findElement(By.linkText("Ownership")).isDisplayed())
				{
					System.out.println("------------ownership ------------");
					List<String>ownership=new ArrayList<String>();
					ownership.add("Originator");
					ownership.add("Co-Owners");
					ownership.add("Last Update User");
					ownership.add("Segment");
					ownership.add("Approvers");
					ownership.add("Last Update Date");
					List<String>p=new ArrayList<String>();
					List<String>perfolist1=new ArrayList<String>();
					WebElement content=driver.findElement(By.id("eight"));
					List<WebElement>l=content.findElements(By.id("pageheaders"));
					for(WebElement col:l) {
						String ss=col.getText();
						p.add(ss);
					}
					for(String s:p) {
						for(String ss:s.split(":")) {
							perfolist1.add(ss);
						}
					}
					for(String s:ownership) {
						int count=0;
						for(String s1:perfolist1) {
							if(s.equalsIgnoreCase(s1)) {
								System.out.println(s+" is present on webpage");
								break;
							}
							else {
								count+=1;
								if(count>=l.size()) {
									System.out.println(s+"not in webpage");
								}
								continue;
							}
						}
					}
				}

			}
			catch(Exception e) {
				System.out.println("Ownership web element not found in webpage");
				System.out.println();
			}
		}
		
		public void ipclass() {
			System.out.println("\n");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[5]/div[1]/div")).isDisplayed())
					//			if(d.findElement(By.linkText("IP Classes")).isDisplayed())
				{
					System.out.println("************ipclass************");
					List<String>ip=new ArrayList<String>();
					ip.add("Name");
					ip.add("Has Class Access?");
					ip.add("Type");
					ip.add("Description");
					ip.add("State");

					List<String>iplist=new ArrayList<String>();
					WebElement table=driver.findElement(By.xpath("//*[@id=\"nine\"]/div/div/table/thead"));
					List<WebElement> rows=table.findElements(By.tagName("tr"));
					List<WebElement> cols=rows.get(1).findElements(By.tagName("th"));
					for(WebElement w:cols) {
						String t=w.getText();
						iplist.add(t);
						//System.out.println(t);
					}
					for(String s:ip) {
						int count=0;
						for(String w:iplist) {
							if(s.equalsIgnoreCase(w)) {
								System.out.println(s+" is present on webpage");
								break;
							}
							else {
								count+=1;
								if(count>=iplist.size()) {
									System.out.println(s+" not in webpage");
								}
								continue;
							}
						}
					}
				}
			}
			catch(Exception e) {
				System.out.println("IP Classes web element not found in webpage");
				System.out.println();
			}
		}
		
		public void organizations() {
			System.out.println("\n");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[6]/div[1]/div")).isDisplayed())
					//			if(d.findElement(By.linkText("Organizations")).isDisplayed())
				{
					System.out.println("*************organizations************");
					List<String>organizations=new ArrayList<String>();
					organizations.add("Primary Organization:");
					organizations.add("Secondary Organization:");

					WebElement table=driver.findElement(By.id("elevan"));
					List<WebElement>l=table.findElements(By.id("pageheaders"));
					for(String s:organizations) {
						int count=0;
						for(WebElement w:l) {
							String s1=w.getText();
							if(s.equalsIgnoreCase(s1)) {
								System.out.println(s+" is present on webpage");
								break;
							}
							else {
								count+=1;
								if(count>=l.size()) {
									System.out.println(s+"not in webpage");
								}
								continue;
							}
						}
					}
				}
			}
			catch(Exception e) {
				System.out.println("Organizations web element not found in webpage");
				System.out.println();
			}
		}
		
		public void Performance_Characteristic() {
			System.out.println("\n");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.xpath("//*[@id=\"print\"]/div[2]/div/div[2]/div[1]/div")).isDisplayed())
				{
					System.out.println("*************performance characteristics************");
					List<String>perfo=new ArrayList<String>();
					perfo.add("Characteristic(Ch) Characteristic Specifics(CS)");
					perfo.add("Chg.");
					perfo.add("Test Method (Name) Test Method Logic (TML) Test Method Origin (TMO) Other Test Method Number (TM#) Test Method Specifics (Sp) Test Method Reference Document Name (TMRDN)");//copied from webpage
					perfo.add("Sampling(SM) Subgroup(SG)");
					perfo.add("Plant Testing Level(LVL) Plant Testing:Retesting(RT) Retesting Unit Of Measure(UoM)");//copied from webpage
					perfo.add("Lower Specification Limit (LSL) Lower Routine Release Limit (LRRL) Lower Target (LTGT) Target (TGT) Upper Target (UTGT) Upper Routine Release Limit (URRL) Upper Specification Limit (USL)");//copied from webpage
					perfo.add("Unit of Measure(UoM) Report to Nearest(RTN) Report Type(RT)");
					perfo.add("Release Criteria(RC)");
					perfo.add("Action Required(AC) Criticality Factor(CR) Basis(BA)");
					perfo.add("Test Group(TG) Application(AP)");
					perfo.add("CH");
					perfo.add("CS");
					perfo.add("Name");
					perfo.add("TML");
					perfo.add("TMO");
					perfo.add("TM#");
					perfo.add("SP");
					perfo.add("TMRDN");
					perfo.add("SM");
					perfo.add("SG");
					perfo.add("LVL");
					perfo.add("RT");
					perfo.add("UoM");
					perfo.add("LSL");
					perfo.add("LRRL");
					perfo.add("LTGT");
					perfo.add("TGT");
					perfo.add("UTGT");
					perfo.add("URRL");
					perfo.add("USL");
					perfo.add("UoM");
					perfo.add("RTN");
					perfo.add("RT");
					perfo.add("RC");
					perfo.add("AC");
					perfo.add("CR");
					perfo.add("BA");
					perfo.add("TG");
					perfo.add("AP");

					List<String>perfolist1=new ArrayList<String>();
					WebElement table=driver.findElement(By.xpath("//*[@id=\"six\"]/div/div/table/thead"));
					List<WebElement>rows=table.findElements(By.tagName("tr"));
					List<WebElement>cols=rows.get(0).findElements(By.tagName("th"));//header column
					for(WebElement col:cols) {
						String ss=col.getText();
						perfolist1.add(ss);
					}
					List<String>p=new ArrayList<String>();
					WebElement table2=driver.findElement(By.xpath("//*[@id=\"six\"]/div/div/table/tbody"));
					List<WebElement>rows2=table2.findElements(By.tagName("tr"));
					List<WebElement>colsd2=rows2.get(0).findElements(By.className("bomFontClass"));
					for(WebElement col:colsd2) {
						String ss=col.getText();
						p.add(ss);
					}
					for(String s:p) {
						for(String ss:s.split(":")) {
							perfolist1.add(ss);
						}
					}
					for(String s:perfo) {
						int count=0;
						for(String s1:perfolist1) {
							if(s.equalsIgnoreCase(s1)) {
								System.out.println(s+" is present on webpage");	
								break;
							}
							else {
								count+=1;
								if(count>=perfolist1.size()) {
									System.out.println(s+" not in webpage");
								}
								continue;
							}
						}
					}
				}
			}
			catch(Exception e) {
				System.out.println("Performance Characteristic web element not found in webpage");
				System.out.println();
			}
		}
		//-----------------------------------------not present--------------
		
		public void Notes() {
			System.out.println("\n");
			System.out.println("*************Notes************");
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.linkText("Notes")).isDisplayed())
				{}
			}
			catch(Exception e) {
				System.out.println("Notes elements is present in template but missing in webpage");
				System.out.println();
			}
		}
		
		public void BillOfMaterials() {
			System.out.println("\n");
			System.out.println("*************BillOfMaterials************");
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.linkText("BillOfMaterials")).isDisplayed())
				{}
			}
			catch(Exception e) {
				System.out.println("BillOfMaterials elements is present in template but missing in webpage");
				System.out.println();
			}
		}

		public void RelatedSpecifications() {
			System.out.println("\n");
			System.out.println("*************Related Specifications***********");
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.linkText("Related Specifications")).isDisplayed())
				{}
			}
			catch(Exception e) {
				System.out.println("Related Specifications elements is present in template but missing in webpage");
				System.out.println();
			}
		}
		
		public void ReferenceDocuments() {
			System.out.println("\n");
			System.out.println("*************Reference documents***********");
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.linkText("Reference documents")).isDisplayed())
				{}
			}
			catch(Exception e) {
				System.out.println("Reference documents elements is present in template but missing in webpage");
				System.out.println();
			}
		}
		
		public void SecurityClasses() {
			System.out.println("\n");
			System.out.println("*************Security Classes************");
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.linkText("Security Classes")).isDisplayed())
				{}
			}
			catch(Exception e) {
				System.out.println("Security Classes elements is present in template but missing in webpage");
				System.out.println();
			}
	}
		
		public void Files() {
			System.out.println("\n");
			System.out.println("************files***********");
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.linkText("files")).isDisplayed())
				{
				}
			}
			catch(Exception e) {
				System.out.println("files elements is present in template but missing in webpage");
				System.out.println();
			}
		}
		
		public void Substitutes() {
			System.out.println("\n");
			System.out.println("************Substitutes************");
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.linkText("Substitutes")).isDisplayed())
				{}
			}
			catch(Exception e) {
				System.out.println("Substitutes elements is present in template but missing in webpage");
				System.out.println();
			}
		}
		
		public void Lifecyle_approval_preview() {
			System.out.println("\n");
			System.out.println("*************Lifecyle_approval_preview***********");
//			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			try {
				if(driver.findElement(By.linkText("Lifecyle_approval_preview")).isDisplayed()) {}
			}
			catch(Exception e) {
				System.out.println("Lifecyle_approval_preview elements is present in template but missing in webpage");
				System.out.println();
			}
		}
		public void After() {
			System.out.println();
			System.out.println("___________________ MIP Successfully Completed ______________________");
			System.out.println();
		}
	}

